using System.Collections.Generic;
using WarehouseAccounting.Core.Models;

namespace WarehouseAccounting.Core.Data
{
    public interface IWarehouseRepository
    {
        IReadOnlyList<Product> GetAllProducts();
        Product? GetProductById(int id);
        Product AddProduct(Product product);
        void UpdateProduct(Product product);
        bool DeleteProduct(int id);

        IReadOnlyList<Category> GetAllCategories();
        Category? GetCategoryById(int id);
        Category AddCategory(Category category);
        void UpdateCategory(Category category);
        bool DeleteCategory(int id);

        IReadOnlyList<Counterparty> GetAllCounterparties();
        Counterparty AddCounterparty(Counterparty counterparty);

        IReadOnlyList<WarehouseOperation> GetAllOperations();
        void AddOperation(WarehouseOperation operation);

        void Save();
        void Load();
        void ResetToDemoData();
    }
}
