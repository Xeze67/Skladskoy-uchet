using System;
using System.Collections.Generic;
using System.Data;
using System.Data.OleDb;
using System.IO;
using WarehouseAccounting.Core.Models;

namespace WarehouseAccounting.Core.Data
{
    public class AccessWarehouseRepository : IWarehouseRepository
    {
        private readonly string _connectionString;
        private readonly string _dbPath;
        private readonly object _lock = new();

        public string DatabasePath => _dbPath;

        public AccessWarehouseRepository(string? dbPath = null)
        {
            if (string.IsNullOrWhiteSpace(dbPath))
            {
                _dbPath = FindDatabasePath();
            }
            else
            {
                _dbPath = dbPath;
            }

            // Using Microsoft.ACE.OLEDB.12.0 for .accdb Access databases
            _connectionString = $"Provider=Microsoft.ACE.OLEDB.12.0;Data Source={_dbPath};Persist Security Info=False;";

            EnsureDatabaseAndTables();
        }

        public static string FindDatabasePath()
        {
            // Search upwards for solution root containing WarehouseAccounting.sln
            try
            {
                var dir = new DirectoryInfo(AppDomain.CurrentDomain.BaseDirectory);
                while (dir != null)
                {
                    string slnCandidate = Path.Combine(dir.FullName, "WarehouseAccounting.sln");
                    if (File.Exists(slnCandidate))
                    {
                        return Path.Combine(dir.FullName, "warehouse.accdb");
                    }

                    dir = dir.Parent;
                }
            }
            catch
            {
            }

            // Fallback: look for warehouse.accdb in current directory or upwards
            try
            {
                var dir = new DirectoryInfo(AppDomain.CurrentDomain.BaseDirectory);
                while (dir != null)
                {
                    string candidate = Path.Combine(dir.FullName, "warehouse.accdb");
                    if (File.Exists(candidate))
                    {
                        return candidate;
                    }

                    dir = dir.Parent;
                }
            }
            catch
            {
            }

            return Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "warehouse.accdb");
        }

        private void EnsureDatabaseAndTables()
        {
            lock (_lock)
            {
                if (!File.Exists(_dbPath))
                {
                    CreateDatabaseFile(_dbPath);
                }

                using var conn = new OleDbConnection(_connectionString);
                conn.Open();

                // Check and create Categories table
                if (!TableExists(conn, "Categories"))
                {
                    using var cmd = conn.CreateCommand();
                    cmd.CommandText = "CREATE TABLE Categories (Id AUTOINCREMENT PRIMARY KEY, [Name] TEXT(150), Description MEMO)";
                    cmd.ExecuteNonQuery();

                    // Seed default categories
                    cmd.CommandText = "INSERT INTO Categories ([Name], Description) VALUES ('Общая', 'Основная категория номенклатуры')";
                    cmd.ExecuteNonQuery();
                    cmd.CommandText = "INSERT INTO Categories ([Name], Description) VALUES ('Инструменты', 'Ручной и электрический инструмент')";
                    cmd.ExecuteNonQuery();
                    cmd.CommandText = "INSERT INTO Categories ([Name], Description) VALUES ('Материалы и расходники', 'Крепеж, химия, расходные материалы')";
                    cmd.ExecuteNonQuery();
                }

                // Check and create Counterparties table
                if (!TableExists(conn, "Counterparties"))
                {
                    using var cmd = conn.CreateCommand();
                    cmd.CommandText = "CREATE TABLE Counterparties (Id AUTOINCREMENT PRIMARY KEY, [Name] TEXT(200), [Type] INT, Phone TEXT(50), Email TEXT(100), Address TEXT(255))";
                    cmd.ExecuteNonQuery();

                    cmd.CommandText = "INSERT INTO Counterparties ([Name], [Type], Phone, Email, Address) VALUES ('Основной поставщик', 0, '+7 (495) 000-00-00', 'supplier@warehouse.ru', 'г. Москва')";
                    cmd.ExecuteNonQuery();
                    cmd.CommandText = "INSERT INTO Counterparties ([Name], [Type], Phone, Email, Address) VALUES ('Розничный покупатель', 1, '+7 (900) 000-00-00', 'client@warehouse.ru', 'г. Москва')";
                    cmd.ExecuteNonQuery();
                }

                // Check and create Products table
                if (!TableExists(conn, "Products"))
                {
                    using var cmd = conn.CreateCommand();
                    cmd.CommandText = "CREATE TABLE Products (Id AUTOINCREMENT PRIMARY KEY, Sku TEXT(50), [Name] TEXT(255), CategoryId INT, CategoryName TEXT(150), Unit TEXT(30), PurchasePrice CURRENCY, SellingPrice CURRENCY, Quantity DOUBLE, MinQuantity DOUBLE, StorageLocation TEXT(100))";
                    cmd.ExecuteNonQuery();
                }

                // Check and create WarehouseOperations table
                if (!TableExists(conn, "WarehouseOperations"))
                {
                    using var cmd = conn.CreateCommand();
                    cmd.CommandText = "CREATE TABLE WarehouseOperations (Id AUTOINCREMENT PRIMARY KEY, DocumentNumber TEXT(50), [Date] DATETIME, [Type] INT, ProductId INT, ProductSku TEXT(50), ProductName TEXT(255), Unit TEXT(30), Quantity DOUBLE, Price CURRENCY, CounterpartyId INT, CounterpartyName TEXT(200), ResponsiblePerson TEXT(100), Comment MEMO)";
                    cmd.ExecuteNonQuery();
                }

                // If Products table is empty, seed initial catalog
                using (var cmdCount = new OleDbCommand("SELECT COUNT(*) FROM Products", conn))
                {
                    int count = Convert.ToInt32(cmdCount.ExecuteScalar() ?? 0);
                    if (count == 0)
                    {
                        SeedInitialData(conn);
                    }
                }
            }
        }

        private void SeedInitialData(OleDbConnection conn)
        {
            // Seed Categories if needed
            using (var cmdCat = new OleDbCommand("SELECT COUNT(*) FROM Categories", conn))
            {
                if (Convert.ToInt32(cmdCat.ExecuteScalar() ?? 0) <= 3)
                {
                    using var del = new OleDbCommand("DELETE FROM Categories", conn);
                    del.ExecuteNonQuery();

                    string[] cats =
                    {
                        "INSERT INTO Categories ([Name], Description) VALUES ('Электроинструмент', 'Дрели, перфораторы, УШМ, шуруповерты')",
                        "INSERT INTO Categories ([Name], Description) VALUES ('Крепеж и метизы', 'Саморезы, болты, гайки, анкеры')",
                        "INSERT INTO Categories ([Name], Description) VALUES ('Ручной инструмент', 'Молотки, отвертки, ключи, рулетки')",
                        "INSERT INTO Categories ([Name], Description) VALUES ('Строительная химия', 'Герметики, пена монтажная, клеи, краски')",
                        "INSERT INTO Categories ([Name], Description) VALUES ('Электрика и кабель', 'Кабель ВВГнг, розетки, автоматы, гофра')"
                    };
                    foreach (var sql in cats)
                    {
                        using var ins = new OleDbCommand(sql, conn);
                        ins.ExecuteNonQuery();
                    }
                }
            }

            // Seed Products
            string productSql = "INSERT INTO Products (Sku, [Name], CategoryId, CategoryName, Unit, PurchasePrice, SellingPrice, Quantity, MinQuantity, StorageLocation) " +
                                "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

            var sampleProducts = new[]
            {
                ("TL-00101", "Дрель ударная Bosch GSB 13 RE", 1, "Электроинструмент", "шт.", 4500m, 6200m, 14.0, 5.0, "Стеллаж A-1"),
                ("TL-00102", "Шуруповерт аккумуляторный Makita DF333", 1, "Электроинструмент", "шт.", 5800m, 7900m, 3.0, 5.0, "Стеллаж A-2"),
                ("TL-00103", "УШМ (Болгарка) Интерскол 125/900", 1, "Электроинструмент", "шт.", 2900m, 4100m, 8.0, 4.0, "Стеллаж A-3"),
                ("FX-00201", "Саморезы по дереву 3.5х35 (пачка 1000 шт)", 2, "Крепеж и метизы", "упак.", 320m, 550m, 45.0, 15.0, "Стеллаж B-1"),
                ("FX-00202", "Анкер клиновой 10х100 (50 шт)", 2, "Крепеж и метизы", "упак.", 650m, 980m, 4.0, 10.0, "Стеллаж B-2"),
                ("HT-00301", "Набор отверток диэлектрических 6 шт Gross", 3, "Ручной инструмент", "компл.", 1100m, 1650m, 12.0, 5.0, "Стеллаж C-1"),
                ("HT-00302", "Рулетка строительная 5м магнитная Matrix", 3, "Ручной инструмент", "шт.", 280m, 490m, 25.0, 10.0, "Стеллаж C-2"),
                ("CH-00401", "Пена монтажная всесезонная Soudal 750 мл", 4, "Строительная химия", "баллон", 410m, 650m, 2.0, 12.0, "Стеллаж D-1"),
                ("CH-00402", "Герметик силиконовый нейтральный Момент 280 мл", 4, "Строительная химия", "туба", 340m, 520m, 18.0, 8.0, "Стеллаж D-2"),
                ("EL-00501", "Кабель силовой ВВГнг-LS 3х2.5 (бухта 100 м)", 5, "Электрика и кабель", "бухта", 6200m, 8400m, 9.0, 3.0, "Стеллаж E-1"),
                ("EL-00502", "Автоматический выключатель 16А 1P ВА47-29 IEK", 5, "Электрика и кабель", "шт.", 190m, 310m, 60.0, 20.0, "Стеллаж E-2")
            };

            foreach (var p in sampleProducts)
            {
                using var cmd = new OleDbCommand(productSql, conn);
                cmd.Parameters.Add("?", OleDbType.VarWChar).Value = p.Item1;
                cmd.Parameters.Add("?", OleDbType.VarWChar).Value = p.Item2;
                cmd.Parameters.Add("?", OleDbType.Integer).Value = p.Item3;
                cmd.Parameters.Add("?", OleDbType.VarWChar).Value = p.Item4;
                cmd.Parameters.Add("?", OleDbType.VarWChar).Value = p.Item5;
                cmd.Parameters.Add("?", OleDbType.Currency).Value = p.Item6;
                cmd.Parameters.Add("?", OleDbType.Currency).Value = p.Item7;
                cmd.Parameters.Add("?", OleDbType.Double).Value = p.Item8;
                cmd.Parameters.Add("?", OleDbType.Double).Value = p.Item9;
                cmd.Parameters.Add("?", OleDbType.VarWChar).Value = p.Item10;
                cmd.ExecuteNonQuery();
            }

            // Seed initial Operations
            string opSql = "INSERT INTO WarehouseOperations (DocumentNumber, [Date], [Type], ProductId, ProductSku, ProductName, Unit, Quantity, Price, CounterpartyId, CounterpartyName, ResponsiblePerson, Comment) " +
                           "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

            var sampleOps = new[]
            {
                ("ПР-0001", DateTime.Now.AddDays(-10), 0, 1, "TL-00101", "Дрель ударная Bosch GSB 13 RE", "шт.", 15.0, 4500m, (int?)1, "ООО 'ТехноСнабКомплект'", "Ложкин", "Первичное поступление на склад"),
                ("ПР-0002", DateTime.Now.AddDays(-9), 0, 2, "TL-00102", "Шуруповерт аккумуляторный Makita DF333", "шт.", 5.0, 5800m, (int?)1, "ООО 'ТехноСнабКомплект'", "Ложкин", "Поступление партии инструмента"),
                ("РХ-0001", DateTime.Now.AddDays(-5), 1, 1, "TL-00101", "Дрель ударная Bosch GSB 13 RE", "шт.", 1.0, 6200m, (int?)2, "Розничный покупатель", "Барышев", "Продажа клиенту"),
                ("РХ-0002", DateTime.Now.AddDays(-3), 1, 2, "TL-00102", "Шуруповерт аккумуляторный Makita DF333", "шт.", 2.0, 7900m, (int?)2, "Розничный покупатель", "Барышев", "Отгрузка розничному клиенту"),
                ("СП-0001", DateTime.Now.AddDays(-2), 2, 8, "CH-00401", "Пена монтажная всесезонная Soudal 750 мл", "баллон", 1.0, 410m, (int?)null, "-", "Рейтер", "Повреждение баллона при разгрузке"),
                ("ИНВ-0001", DateTime.Now.AddDays(-1), 3, 4, "FX-00201", "Саморезы по дереву 3.5х35 (пачка 1000 шт)", "упак.", 45.0, 320m, (int?)null, "-", "Ложкин", "Плановая ревизия стеллажа B-1")
            };

            foreach (var op in sampleOps)
            {
                using var cmd = new OleDbCommand(opSql, conn);
                cmd.Parameters.Add("?", OleDbType.VarWChar).Value = op.Item1;
                cmd.Parameters.Add("?", OleDbType.Date).Value = op.Item2;
                cmd.Parameters.Add("?", OleDbType.Integer).Value = op.Item3;
                cmd.Parameters.Add("?", OleDbType.Integer).Value = op.Item4;
                cmd.Parameters.Add("?", OleDbType.VarWChar).Value = op.Item5;
                cmd.Parameters.Add("?", OleDbType.VarWChar).Value = op.Item6;
                cmd.Parameters.Add("?", OleDbType.VarWChar).Value = op.Item7;
                cmd.Parameters.Add("?", OleDbType.Double).Value = op.Item8;
                cmd.Parameters.Add("?", OleDbType.Currency).Value = op.Item9;
                cmd.Parameters.Add("?", OleDbType.Integer).Value = (object?)op.Item10 ?? DBNull.Value;
                cmd.Parameters.Add("?", OleDbType.VarWChar).Value = op.Item11;
                cmd.Parameters.Add("?", OleDbType.VarWChar).Value = op.Item12;
                cmd.Parameters.Add("?", OleDbType.VarWChar).Value = op.Item13;
                cmd.ExecuteNonQuery();
            }
        }

        private static void CreateDatabaseFile(string path)
        {
            var dir = Path.GetDirectoryName(path);
            if (!string.IsNullOrEmpty(dir) && !Directory.Exists(dir))
            {
                Directory.CreateDirectory(dir);
            }

            var catType = Type.GetTypeFromProgID("ADOX.Catalog");
            if (catType != null)
            {
                dynamic cat = Activator.CreateInstance(catType)!;
                try
                {
                    cat.Create($"Provider=Microsoft.ACE.OLEDB.12.0;Data Source={path};");
                }
                finally
                {
                    System.Runtime.InteropServices.Marshal.ReleaseComObject(cat);
                }
            }
        }

        private static bool TableExists(OleDbConnection conn, string tableName)
        {
            var schema = conn.GetSchema("Tables", new[] { null, null, tableName, "TABLE" });
            return schema.Rows.Count > 0;
        }

        public IReadOnlyList<Product> GetAllProducts()
        {
            lock (_lock)
            {
                var list = new List<Product>();
                using var conn = new OleDbConnection(_connectionString);
                conn.Open();

                using var cmd = new OleDbCommand("SELECT Id, Sku, [Name], CategoryId, CategoryName, Unit, PurchasePrice, SellingPrice, Quantity, MinQuantity, StorageLocation FROM Products ORDER BY [Name]", conn);
                using var reader = cmd.ExecuteReader();
                while (reader.Read())
                {
                    list.Add(new Product
                    {
                        Id = Convert.ToInt32(reader["Id"]),
                        Sku = reader["Sku"]?.ToString() ?? string.Empty,
                        Name = reader["Name"]?.ToString() ?? string.Empty,
                        CategoryId = reader["CategoryId"] != DBNull.Value ? Convert.ToInt32(reader["CategoryId"]) : 1,
                        CategoryName = reader["CategoryName"]?.ToString() ?? "Общая",
                        Unit = reader["Unit"]?.ToString() ?? "шт.",
                        PurchasePrice = reader["PurchasePrice"] != DBNull.Value ? Convert.ToDecimal(reader["PurchasePrice"]) : 0m,
                        SellingPrice = reader["SellingPrice"] != DBNull.Value ? Convert.ToDecimal(reader["SellingPrice"]) : 0m,
                        Quantity = reader["Quantity"] != DBNull.Value ? Convert.ToDecimal(reader["Quantity"]) : 0m,
                        MinQuantity = reader["MinQuantity"] != DBNull.Value ? Convert.ToDecimal(reader["MinQuantity"]) : 0m,
                        StorageLocation = reader["StorageLocation"]?.ToString() ?? string.Empty
                    });
                }
                return list;
            }
        }

        public Product? GetProductById(int id)
        {
            lock (_lock)
            {
                using var conn = new OleDbConnection(_connectionString);
                conn.Open();

                using var cmd = new OleDbCommand("SELECT Id, Sku, [Name], CategoryId, CategoryName, Unit, PurchasePrice, SellingPrice, Quantity, MinQuantity, StorageLocation FROM Products WHERE Id = ?", conn);
                cmd.Parameters.Add("?", OleDbType.Integer).Value = id;

                using var reader = cmd.ExecuteReader();
                if (reader.Read())
                {
                    return new Product
                    {
                        Id = Convert.ToInt32(reader["Id"]),
                        Sku = reader["Sku"]?.ToString() ?? string.Empty,
                        Name = reader["Name"]?.ToString() ?? string.Empty,
                        CategoryId = reader["CategoryId"] != DBNull.Value ? Convert.ToInt32(reader["CategoryId"]) : 1,
                        CategoryName = reader["CategoryName"]?.ToString() ?? "Общая",
                        Unit = reader["Unit"]?.ToString() ?? "шт.",
                        PurchasePrice = reader["PurchasePrice"] != DBNull.Value ? Convert.ToDecimal(reader["PurchasePrice"]) : 0m,
                        SellingPrice = reader["SellingPrice"] != DBNull.Value ? Convert.ToDecimal(reader["SellingPrice"]) : 0m,
                        Quantity = reader["Quantity"] != DBNull.Value ? Convert.ToDecimal(reader["Quantity"]) : 0m,
                        MinQuantity = reader["MinQuantity"] != DBNull.Value ? Convert.ToDecimal(reader["MinQuantity"]) : 0m,
                        StorageLocation = reader["StorageLocation"]?.ToString() ?? string.Empty
                    };
                }
                return null;
            }
        }

        public Product AddProduct(Product product)
        {
            lock (_lock)
            {
                using var conn = new OleDbConnection(_connectionString);
                conn.Open();

                string sql = "INSERT INTO Products (Sku, [Name], CategoryId, CategoryName, Unit, PurchasePrice, SellingPrice, Quantity, MinQuantity, StorageLocation) " +
                             "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
                using (var cmd = new OleDbCommand(sql, conn))
                {
                    cmd.Parameters.Add("?", OleDbType.VarWChar).Value = product.Sku ?? string.Empty;
                    cmd.Parameters.Add("?", OleDbType.VarWChar).Value = product.Name ?? string.Empty;
                    cmd.Parameters.Add("?", OleDbType.Integer).Value = product.CategoryId;
                    cmd.Parameters.Add("?", OleDbType.VarWChar).Value = product.CategoryName ?? "Общая";
                    cmd.Parameters.Add("?", OleDbType.VarWChar).Value = product.Unit ?? "шт.";
                    cmd.Parameters.Add("?", OleDbType.Currency).Value = product.PurchasePrice;
                    cmd.Parameters.Add("?", OleDbType.Currency).Value = product.SellingPrice;
                    cmd.Parameters.Add("?", OleDbType.Double).Value = Convert.ToDouble(product.Quantity);
                    cmd.Parameters.Add("?", OleDbType.Double).Value = Convert.ToDouble(product.MinQuantity);
                    cmd.Parameters.Add("?", OleDbType.VarWChar).Value = product.StorageLocation ?? string.Empty;
                    cmd.ExecuteNonQuery();
                }

                // Get inserted Identity ID
                using (var cmdId = new OleDbCommand("SELECT @@IDENTITY", conn))
                {
                    var result = cmdId.ExecuteScalar();
                    if (result != null && result != DBNull.Value)
                    {
                        product.Id = Convert.ToInt32(result);
                    }
                }

                return product;
            }
        }

        public void UpdateProduct(Product product)
        {
            lock (_lock)
            {
                using var conn = new OleDbConnection(_connectionString);
                conn.Open();

                string sql = "UPDATE Products SET Sku = ?, [Name] = ?, CategoryId = ?, CategoryName = ?, Unit = ?, PurchasePrice = ?, SellingPrice = ?, Quantity = ?, MinQuantity = ?, StorageLocation = ? WHERE Id = ?";
                using var cmd = new OleDbCommand(sql, conn);
                cmd.Parameters.Add("?", OleDbType.VarWChar).Value = product.Sku ?? string.Empty;
                cmd.Parameters.Add("?", OleDbType.VarWChar).Value = product.Name ?? string.Empty;
                cmd.Parameters.Add("?", OleDbType.Integer).Value = product.CategoryId;
                cmd.Parameters.Add("?", OleDbType.VarWChar).Value = product.CategoryName ?? "Общая";
                cmd.Parameters.Add("?", OleDbType.VarWChar).Value = product.Unit ?? "шт.";
                cmd.Parameters.Add("?", OleDbType.Currency).Value = product.PurchasePrice;
                cmd.Parameters.Add("?", OleDbType.Currency).Value = product.SellingPrice;
                cmd.Parameters.Add("?", OleDbType.Double).Value = Convert.ToDouble(product.Quantity);
                cmd.Parameters.Add("?", OleDbType.Double).Value = Convert.ToDouble(product.MinQuantity);
                cmd.Parameters.Add("?", OleDbType.VarWChar).Value = product.StorageLocation ?? string.Empty;
                cmd.Parameters.Add("?", OleDbType.Integer).Value = product.Id;
                cmd.ExecuteNonQuery();
            }
        }

        public bool DeleteProduct(int id)
        {
            lock (_lock)
            {
                using var conn = new OleDbConnection(_connectionString);
                conn.Open();

                using var cmd = new OleDbCommand("DELETE FROM Products WHERE Id = ?", conn);
                cmd.Parameters.Add("?", OleDbType.Integer).Value = id;
                return cmd.ExecuteNonQuery() > 0;
            }
        }

        public IReadOnlyList<Category> GetAllCategories()
        {
            lock (_lock)
            {
                var list = new List<Category>();
                using var conn = new OleDbConnection(_connectionString);
                conn.Open();

                using var cmd = new OleDbCommand("SELECT Id, [Name], Description FROM Categories ORDER BY [Name]", conn);
                using var reader = cmd.ExecuteReader();
                while (reader.Read())
                {
                    list.Add(new Category
                    {
                        Id = Convert.ToInt32(reader["Id"]),
                        Name = reader["Name"]?.ToString() ?? string.Empty,
                        Description = reader["Description"]?.ToString() ?? string.Empty
                    });
                }
                return list;
            }
        }

        public Category? GetCategoryById(int id)
        {
            lock (_lock)
            {
                using var conn = new OleDbConnection(_connectionString);
                conn.Open();

                using var cmd = new OleDbCommand("SELECT Id, [Name], Description FROM Categories WHERE Id = ?", conn);
                cmd.Parameters.Add("?", OleDbType.Integer).Value = id;

                using var reader = cmd.ExecuteReader();
                if (reader.Read())
                {
                    return new Category
                    {
                        Id = Convert.ToInt32(reader["Id"]),
                        Name = reader["Name"]?.ToString() ?? string.Empty,
                        Description = reader["Description"]?.ToString() ?? string.Empty
                    };
                }
                return null;
            }
        }

        public Category AddCategory(Category category)
        {
            lock (_lock)
            {
                using var conn = new OleDbConnection(_connectionString);
                conn.Open();

                string sql = "INSERT INTO Categories ([Name], Description) VALUES (?, ?)";
                using (var cmd = new OleDbCommand(sql, conn))
                {
                    cmd.Parameters.Add("?", OleDbType.VarWChar).Value = category.Name ?? string.Empty;
                    cmd.Parameters.Add("?", OleDbType.VarWChar).Value = category.Description ?? string.Empty;
                    cmd.ExecuteNonQuery();
                }

                using (var cmdId = new OleDbCommand("SELECT @@IDENTITY", conn))
                {
                    var result = cmdId.ExecuteScalar();
                    if (result != null && result != DBNull.Value)
                    {
                        category.Id = Convert.ToInt32(result);
                    }
                }

                return category;
            }
        }

        public void UpdateCategory(Category category)
        {
            lock (_lock)
            {
                using var conn = new OleDbConnection(_connectionString);
                conn.Open();

                string sql = "UPDATE Categories SET [Name] = ?, Description = ? WHERE Id = ?";
                using var cmd = new OleDbCommand(sql, conn);
                cmd.Parameters.Add("?", OleDbType.VarWChar).Value = category.Name ?? string.Empty;
                cmd.Parameters.Add("?", OleDbType.VarWChar).Value = category.Description ?? string.Empty;
                cmd.Parameters.Add("?", OleDbType.Integer).Value = category.Id;
                cmd.ExecuteNonQuery();
            }
        }

        public bool DeleteCategory(int id)
        {
            lock (_lock)
            {
                using var conn = new OleDbConnection(_connectionString);
                conn.Open();

                using var cmd = new OleDbCommand("DELETE FROM Categories WHERE Id = ?", conn);
                cmd.Parameters.Add("?", OleDbType.Integer).Value = id;
                return cmd.ExecuteNonQuery() > 0;
            }
        }

        public IReadOnlyList<Counterparty> GetAllCounterparties()
        {
            lock (_lock)
            {
                var list = new List<Counterparty>();
                using var conn = new OleDbConnection(_connectionString);
                conn.Open();

                using var cmd = new OleDbCommand("SELECT Id, [Name], [Type], Phone, Email, Address FROM Counterparties ORDER BY [Name]", conn);
                using var reader = cmd.ExecuteReader();
                while (reader.Read())
                {
                    list.Add(new Counterparty
                    {
                        Id = Convert.ToInt32(reader["Id"]),
                        Name = reader["Name"]?.ToString() ?? string.Empty,
                        Type = (CounterpartyType)Convert.ToInt32(reader["Type"]),
                        Phone = reader["Phone"]?.ToString() ?? string.Empty,
                        Email = reader["Email"]?.ToString() ?? string.Empty,
                        Address = reader["Address"]?.ToString() ?? string.Empty
                    });
                }
                return list;
            }
        }

        public Counterparty AddCounterparty(Counterparty counterparty)
        {
            lock (_lock)
            {
                using var conn = new OleDbConnection(_connectionString);
                conn.Open();

                string sql = "INSERT INTO Counterparties ([Name], [Type], Phone, Email, Address) VALUES (?, ?, ?, ?, ?)";
                using (var cmd = new OleDbCommand(sql, conn))
                {
                    cmd.Parameters.Add("?", OleDbType.VarWChar).Value = counterparty.Name ?? string.Empty;
                    cmd.Parameters.Add("?", OleDbType.Integer).Value = (int)counterparty.Type;
                    cmd.Parameters.Add("?", OleDbType.VarWChar).Value = counterparty.Phone ?? string.Empty;
                    cmd.Parameters.Add("?", OleDbType.VarWChar).Value = counterparty.Email ?? string.Empty;
                    cmd.Parameters.Add("?", OleDbType.VarWChar).Value = counterparty.Address ?? string.Empty;
                    cmd.ExecuteNonQuery();
                }

                using (var cmdId = new OleDbCommand("SELECT @@IDENTITY", conn))
                {
                    var result = cmdId.ExecuteScalar();
                    if (result != null && result != DBNull.Value)
                    {
                        counterparty.Id = Convert.ToInt32(result);
                    }
                }

                return counterparty;
            }
        }

        public IReadOnlyList<WarehouseOperation> GetAllOperations()
        {
            lock (_lock)
            {
                var list = new List<WarehouseOperation>();
                using var conn = new OleDbConnection(_connectionString);
                conn.Open();

                using var cmd = new OleDbCommand("SELECT Id, DocumentNumber, [Date], [Type], ProductId, ProductSku, ProductName, Unit, Quantity, Price, CounterpartyId, CounterpartyName, ResponsiblePerson, Comment FROM WarehouseOperations ORDER BY [Date] DESC", conn);
                using var reader = cmd.ExecuteReader();
                while (reader.Read())
                {
                    list.Add(new WarehouseOperation
                    {
                        Id = Convert.ToInt32(reader["Id"]),
                        DocumentNumber = reader["DocumentNumber"]?.ToString() ?? string.Empty,
                        Date = reader["Date"] != DBNull.Value ? Convert.ToDateTime(reader["Date"]) : DateTime.Now,
                        Type = (OperationType)Convert.ToInt32(reader["Type"]),
                        ProductId = Convert.ToInt32(reader["ProductId"]),
                        ProductSku = reader["ProductSku"]?.ToString() ?? string.Empty,
                        ProductName = reader["ProductName"]?.ToString() ?? string.Empty,
                        Unit = reader["Unit"]?.ToString() ?? "шт.",
                        Quantity = reader["Quantity"] != DBNull.Value ? Convert.ToDecimal(reader["Quantity"]) : 0m,
                        Price = reader["Price"] != DBNull.Value ? Convert.ToDecimal(reader["Price"]) : 0m,
                        CounterpartyId = reader["CounterpartyId"] != DBNull.Value ? Convert.ToInt32(reader["CounterpartyId"]) : null,
                        CounterpartyName = reader["CounterpartyName"]?.ToString() ?? "-",
                        ResponsiblePerson = reader["ResponsiblePerson"]?.ToString() ?? "Кладовщик",
                        Comment = reader["Comment"]?.ToString() ?? string.Empty
                    });
                }
                return list;
            }
        }

        public void AddOperation(WarehouseOperation operation)
        {
            lock (_lock)
            {
                using var conn = new OleDbConnection(_connectionString);
                conn.Open();

                string sql = "INSERT INTO WarehouseOperations (DocumentNumber, [Date], [Type], ProductId, ProductSku, ProductName, Unit, Quantity, Price, CounterpartyId, CounterpartyName, ResponsiblePerson, Comment) " +
                             "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
                using (var cmd = new OleDbCommand(sql, conn))
                {
                    cmd.Parameters.Add("?", OleDbType.VarWChar).Value = operation.DocumentNumber ?? string.Empty;
                    cmd.Parameters.Add("?", OleDbType.Date).Value = operation.Date;
                    cmd.Parameters.Add("?", OleDbType.Integer).Value = (int)operation.Type;
                    cmd.Parameters.Add("?", OleDbType.Integer).Value = operation.ProductId;
                    cmd.Parameters.Add("?", OleDbType.VarWChar).Value = operation.ProductSku ?? string.Empty;
                    cmd.Parameters.Add("?", OleDbType.VarWChar).Value = operation.ProductName ?? string.Empty;
                    cmd.Parameters.Add("?", OleDbType.VarWChar).Value = operation.Unit ?? "шт.";
                    cmd.Parameters.Add("?", OleDbType.Double).Value = Convert.ToDouble(operation.Quantity);
                    cmd.Parameters.Add("?", OleDbType.Currency).Value = operation.Price;
                    cmd.Parameters.Add("?", OleDbType.Integer).Value = (object?)operation.CounterpartyId ?? DBNull.Value;
                    cmd.Parameters.Add("?", OleDbType.VarWChar).Value = operation.CounterpartyName ?? "-";
                    cmd.Parameters.Add("?", OleDbType.VarWChar).Value = operation.ResponsiblePerson ?? "Кладовщик";
                    cmd.Parameters.Add("?", OleDbType.VarWChar).Value = operation.Comment ?? string.Empty;
                    cmd.ExecuteNonQuery();
                }

                using (var cmdId = new OleDbCommand("SELECT @@IDENTITY", conn))
                {
                    var result = cmdId.ExecuteScalar();
                    if (result != null && result != DBNull.Value)
                    {
                        operation.Id = Convert.ToInt32(result);
                    }
                }
            }
        }

        public void Save()
        {
            // OleDb directly writes to MS Access .accdb on each query
        }

        public void Load()
        {
            EnsureDatabaseAndTables();
        }

        public void ResetToDemoData()
        {
            // In MS Access, clear tables and restore clean initial state
            lock (_lock)
            {
                using var conn = new OleDbConnection(_connectionString);
                conn.Open();

                using (var cmd = conn.CreateCommand())
                {
                    cmd.CommandText = "DELETE FROM WarehouseOperations";
                    cmd.ExecuteNonQuery();
                    cmd.CommandText = "DELETE FROM Products";
                    cmd.ExecuteNonQuery();
                }

                SeedInitialData(conn);
            }
        }
    }
}
