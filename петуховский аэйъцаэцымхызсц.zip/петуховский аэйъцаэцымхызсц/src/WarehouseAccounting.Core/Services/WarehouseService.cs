using System;
using System.Collections.Generic;
using System.Linq;
using WarehouseAccounting.Core.Data;
using WarehouseAccounting.Core.Exceptions;
using WarehouseAccounting.Core.Models;

namespace WarehouseAccounting.Core.Services
{
    public class WarehouseService : IWarehouseService
    {
        private readonly IWarehouseRepository _repository;

        public WarehouseService(IWarehouseRepository repository)
        {
            _repository = repository ?? throw new ArgumentNullException(nameof(repository));
        }

        public IReadOnlyList<Product> GetProducts(string? search = null, int? categoryId = null, bool onlyLowStock = false)
        {
            var products = _repository.GetAllProducts().AsEnumerable();

            if (!string.IsNullOrWhiteSpace(search))
            {
                var query = search.Trim().ToLowerInvariant();
                products = products.Where(p =>
                    (p.Name != null && p.Name.ToLowerInvariant().Contains(query)) ||
                    (p.Sku != null && p.Sku.ToLowerInvariant().Contains(query)) ||
                    (p.StorageLocation != null && p.StorageLocation.ToLowerInvariant().Contains(query)));
            }

            if (categoryId.HasValue && categoryId.Value > 0)
            {
                products = products.Where(p => p.CategoryId == categoryId.Value);
            }

            if (onlyLowStock)
            {
                products = products.Where(p => p.IsLowStock);
            }

            return products.OrderBy(p => p.Name).ToList();
        }

        public Product? GetProductById(int id) => _repository.GetProductById(id);

        public Product CreateProduct(Product product)
        {
            ValidateProduct(product);
            var category = _repository.GetCategoryById(product.CategoryId);
            if (category != null)
            {
                product.CategoryName = category.Name;
            }
            return _repository.AddProduct(product);
        }

        public void UpdateProduct(Product product)
        {
            ValidateProduct(product);
            var category = _repository.GetCategoryById(product.CategoryId);
            if (category != null)
            {
                product.CategoryName = category.Name;
            }
            _repository.UpdateProduct(product);
        }

        public bool DeleteProduct(int id) => _repository.DeleteProduct(id);

        public WarehouseOperation ProcessReceipt(int productId, decimal quantity, decimal price, int? counterpartyId, string responsible, string comment)
        {
            if (quantity <= 0)
                throw new WarehouseValidationException("Количество прихода должно быть больше нуля!");
            if (price < 0)
                throw new WarehouseValidationException("Цена закупки не может быть отрицательной!");

            var product = _repository.GetProductById(productId)
                ?? throw new WarehouseValidationException($"Товар с ID={productId} не найден!");

            string counterpartyName = "-";
            if (counterpartyId.HasValue)
            {
                var cp = _repository.GetAllCounterparties().FirstOrDefault(c => c.Id == counterpartyId.Value);
                if (cp != null) counterpartyName = cp.Name;
            }

            // Увеличиваем остаток товара и обновляем цену закупки
            product.Quantity += quantity;
            if (price > 0)
            {
                product.PurchasePrice = price;
            }
            _repository.UpdateProduct(product);

            var operation = new WarehouseOperation
            {
                DocumentNumber = GenerateDocNumber(OperationType.Receipt),
                Date = DateTime.Now,
                Type = OperationType.Receipt,
                ProductId = product.Id,
                ProductSku = product.Sku,
                ProductName = product.Name,
                Unit = product.Unit,
                Quantity = quantity,
                Price = price,
                CounterpartyId = counterpartyId,
                CounterpartyName = counterpartyName,
                ResponsiblePerson = string.IsNullOrWhiteSpace(responsible) ? "Кладовщик" : responsible,
                Comment = comment ?? string.Empty
            };

            _repository.AddOperation(operation);
            return operation;
        }

        public WarehouseOperation ProcessExpense(int productId, decimal quantity, decimal price, int? counterpartyId, string responsible, string comment)
        {
            if (quantity <= 0)
                throw new WarehouseValidationException("Количество отгрузки должно быть больше нуля!");
            if (price < 0)
                throw new WarehouseValidationException("Цена продажи не может быть отрицательной!");

            var product = _repository.GetProductById(productId)
                ?? throw new WarehouseValidationException($"Товар с ID={productId} не найден!");

            if (product.Quantity < quantity)
            {
                throw new InsufficientStockException(product.Id, product.Name, quantity, product.Quantity);
            }

            string counterpartyName = "-";
            if (counterpartyId.HasValue)
            {
                var cp = _repository.GetAllCounterparties().FirstOrDefault(c => c.Id == counterpartyId.Value);
                if (cp != null) counterpartyName = cp.Name;
            }

            // Списываем со склада
            product.Quantity -= quantity;
            _repository.UpdateProduct(product);

            var operation = new WarehouseOperation
            {
                DocumentNumber = GenerateDocNumber(OperationType.Expense),
                Date = DateTime.Now,
                Type = OperationType.Expense,
                ProductId = product.Id,
                ProductSku = product.Sku,
                ProductName = product.Name,
                Unit = product.Unit,
                Quantity = quantity,
                Price = price,
                CounterpartyId = counterpartyId,
                CounterpartyName = counterpartyName,
                ResponsiblePerson = string.IsNullOrWhiteSpace(responsible) ? "Кладовщик" : responsible,
                Comment = comment ?? string.Empty
            };

            _repository.AddOperation(operation);
            return operation;
        }

        public WarehouseOperation ProcessWriteOff(int productId, decimal quantity, string reason, string responsible)
        {
            if (quantity <= 0)
                throw new WarehouseValidationException("Количество списания должно быть больше нуля!");

            var product = _repository.GetProductById(productId)
                ?? throw new WarehouseValidationException($"Товар с ID={productId} не найден!");

            if (product.Quantity < quantity)
            {
                throw new InsufficientStockException(product.Id, product.Name, quantity, product.Quantity);
            }

            product.Quantity -= quantity;
            _repository.UpdateProduct(product);

            var operation = new WarehouseOperation
            {
                DocumentNumber = GenerateDocNumber(OperationType.WriteOff),
                Date = DateTime.Now,
                Type = OperationType.WriteOff,
                ProductId = product.Id,
                ProductSku = product.Sku,
                ProductName = product.Name,
                Unit = product.Unit,
                Quantity = quantity,
                Price = product.PurchasePrice,
                CounterpartyId = null,
                CounterpartyName = "-",
                ResponsiblePerson = string.IsNullOrWhiteSpace(responsible) ? "Кладовщик" : responsible,
                Comment = string.IsNullOrWhiteSpace(reason) ? "Списание брака/порчи" : reason
            };

            _repository.AddOperation(operation);
            return operation;
        }

        public WarehouseOperation ProcessInventory(int productId, decimal actualQuantity, string responsible, string comment)
        {
            if (actualQuantity < 0)
                throw new WarehouseValidationException("Фактическое количество не может быть отрицательным!");

            var product = _repository.GetProductById(productId)
                ?? throw new WarehouseValidationException($"Товар с ID={productId} не найден!");

            decimal diff = actualQuantity - product.Quantity;
            product.Quantity = actualQuantity;
            _repository.UpdateProduct(product);

            var operation = new WarehouseOperation
            {
                DocumentNumber = GenerateDocNumber(OperationType.InventoryAdjustment),
                Date = DateTime.Now,
                Type = OperationType.InventoryAdjustment,
                ProductId = product.Id,
                ProductSku = product.Sku,
                ProductName = product.Name,
                Unit = product.Unit,
                Quantity = actualQuantity,
                Price = product.PurchasePrice,
                CounterpartyId = null,
                CounterpartyName = "-",
                ResponsiblePerson = string.IsNullOrWhiteSpace(responsible) ? "Кладовщик" : responsible,
                Comment = $"Корректировка остатка. Разница: {(diff >= 0 ? "+" : "")}{diff} {product.Unit}. {comment}".Trim()
            };

            _repository.AddOperation(operation);
            return operation;
        }

        public IReadOnlyList<WarehouseOperation> GetOperationsHistory(DateTime? fromDate = null, DateTime? toDate = null, OperationType? type = null)
        {
            var ops = _repository.GetAllOperations().AsEnumerable();

            if (fromDate.HasValue)
            {
                ops = ops.Where(o => o.Date.Date >= fromDate.Value.Date);
            }
            if (toDate.HasValue)
            {
                ops = ops.Where(o => o.Date.Date <= toDate.Value.Date);
            }
            if (type.HasValue)
            {
                ops = ops.Where(o => o.Type == type.Value);
            }

            return ops.OrderByDescending(o => o.Date).ToList();
        }

        public IReadOnlyList<Category> GetCategories() => _repository.GetAllCategories();

        public Category CreateCategory(string name, string description)
        {
            if (string.IsNullOrWhiteSpace(name))
                throw new WarehouseValidationException("Название категории не может быть пустым!");
            return _repository.AddCategory(new Category { Name = name.Trim(), Description = description?.Trim() ?? string.Empty });
        }

        public IReadOnlyList<Counterparty> GetCounterparties() => _repository.GetAllCounterparties();

        public Counterparty CreateCounterparty(string name, CounterpartyType type, string phone, string email, string address)
        {
            if (string.IsNullOrWhiteSpace(name))
                throw new WarehouseValidationException("Наименование контрагента не может быть пустым!");
            return _repository.AddCounterparty(new Counterparty
            {
                Name = name.Trim(),
                Type = type,
                Phone = phone?.Trim() ?? string.Empty,
                Email = email?.Trim() ?? string.Empty,
                Address = address?.Trim() ?? string.Empty
            });
        }

        public DashboardStats GetDashboardStats()
        {
            var products = _repository.GetAllProducts();
            var ops = _repository.GetAllOperations();
            var today = DateTime.Today;

            return new DashboardStats
            {
                TotalItemTypes = products.Count,
                TotalStockQuantity = products.Sum(p => p.Quantity),
                TotalStockValueRub = products.Sum(p => p.TotalStockValue),
                LowStockCount = products.Count(p => p.IsLowStock),
                TotalOperationsCount = ops.Count,
                TodayTurnoverRub = ops.Where(o => o.Date.Date == today && o.Type == OperationType.Expense).Sum(o => o.TotalAmount)
            };
        }

        public void ResetToDemo() => _repository.ResetToDemoData();

        private void ValidateProduct(Product product)
        {
            if (string.IsNullOrWhiteSpace(product.Name))
                throw new WarehouseValidationException("Название товара обязательно для заполнения!");
            if (string.IsNullOrWhiteSpace(product.Sku))
                throw new WarehouseValidationException("Артикул товара обязателен для заполнения!");
            if (product.PurchasePrice < 0)
                throw new WarehouseValidationException("Цена закупки не может быть отрицательной!");
            if (product.SellingPrice < 0)
                throw new WarehouseValidationException("Цена продажи не может быть отрицательной!");
            if (product.Quantity < 0)
                throw new WarehouseValidationException("Количество на складе не может быть отрицательным!");
            if (product.MinQuantity < 0)
                throw new WarehouseValidationException("Минимальный остаток не может быть отрицательным!");
        }

        private string GenerateDocNumber(OperationType type)
        {
            string prefix = type switch
            {
                OperationType.Receipt => "ПР",
                OperationType.Expense => "РХ",
                OperationType.WriteOff => "СП",
                OperationType.InventoryAdjustment => "ИНВ",
                _ => "ДОК"
            };
            int count = _repository.GetAllOperations().Count(o => o.Type == type) + 1;
            return $"{prefix}-{count:D4}";
        }
    }
}
