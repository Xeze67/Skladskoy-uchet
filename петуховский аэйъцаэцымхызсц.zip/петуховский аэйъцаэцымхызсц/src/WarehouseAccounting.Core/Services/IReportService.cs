using System;
using System.Collections.Generic;
using WarehouseAccounting.Core.Models;

namespace WarehouseAccounting.Core.Services
{
    public class StockReportRow
    {
        public string Sku { get; set; } = string.Empty;
        public string Name { get; set; } = string.Empty;
        public string Category { get; set; } = string.Empty;
        public decimal Quantity { get; set; }
        public string Unit { get; set; } = string.Empty;
        public decimal PurchasePrice { get; set; }
        public decimal TotalValue { get; set; }
        public decimal MinQuantity { get; set; }
        public string Status { get; set; } = "В норме";
        public string Location { get; set; } = string.Empty;
    }

    public class DeficitReportRow
    {
        public string Sku { get; set; } = string.Empty;
        public string Name { get; set; } = string.Empty;
        public string Category { get; set; } = string.Empty;
        public decimal CurrentStock { get; set; }
        public decimal MinStock { get; set; }
        public decimal DeficitQuantity { get; set; }
        public decimal RecommendedOrderQuantity { get; set; }
        public decimal EstimatedCostRub { get; set; }
    }

    public class TurnoverReportRow
    {
        public string Sku { get; set; } = string.Empty;
        public string Name { get; set; } = string.Empty;
        public decimal ReceivedQty { get; set; }
        public decimal ReceivedAmount { get; set; }
        public decimal ShippedQty { get; set; }
        public decimal ShippedAmount { get; set; }
        public decimal WrittenOffQty { get; set; }
        public decimal CurrentStock { get; set; }
    }

    public interface IReportService
    {
        IReadOnlyList<StockReportRow> GenerateStockBalanceReport();
        IReadOnlyList<DeficitReportRow> GenerateDeficitReport();
        IReadOnlyList<TurnoverReportRow> GenerateTurnoverReport(DateTime fromDate, DateTime toDate);
        void ExportStockBalanceCsv(string filePath);
        void ExportDeficitCsv(string filePath);
        void ExportTurnoverCsv(string filePath, DateTime fromDate, DateTime toDate);
    }
}
