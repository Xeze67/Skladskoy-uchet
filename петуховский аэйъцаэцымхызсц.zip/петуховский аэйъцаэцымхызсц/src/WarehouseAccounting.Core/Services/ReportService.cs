using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using WarehouseAccounting.Core.Data;
using WarehouseAccounting.Core.Models;

namespace WarehouseAccounting.Core.Services
{
    public class ReportService : IReportService
    {
        private readonly IWarehouseRepository _repository;

        public ReportService(IWarehouseRepository repository)
        {
            _repository = repository ?? throw new ArgumentNullException(nameof(repository));
        }

        public IReadOnlyList<StockReportRow> GenerateStockBalanceReport()
        {
            var products = _repository.GetAllProducts();
            return products.Select(p => new StockReportRow
            {
                Sku = p.Sku,
                Name = p.Name,
                Category = p.CategoryName,
                Quantity = p.Quantity,
                Unit = p.Unit,
                PurchasePrice = p.PurchasePrice,
                TotalValue = p.TotalStockValue,
                MinQuantity = p.MinQuantity,
                Status = p.IsLowStock ? "ДЕФИЦИТ" : "В норме",
                Location = p.StorageLocation
            }).OrderBy(r => r.Category).ThenBy(r => r.Name).ToList();
        }

        public IReadOnlyList<DeficitReportRow> GenerateDeficitReport()
        {
            var products = _repository.GetAllProducts().Where(p => p.IsLowStock).ToList();
            return products.Select(p =>
            {
                decimal deficit = p.MinQuantity - p.Quantity;
                if (deficit < 0) deficit = 0;
                decimal recommended = (p.MinQuantity * 2m) - p.Quantity;
                if (recommended <= 0) recommended = p.MinQuantity;

                return new DeficitReportRow
                {
                    Sku = p.Sku,
                    Name = p.Name,
                    Category = p.CategoryName,
                    CurrentStock = p.Quantity,
                    MinStock = p.MinQuantity,
                    DeficitQuantity = deficit,
                    RecommendedOrderQuantity = recommended,
                    EstimatedCostRub = recommended * p.PurchasePrice
                };
            }).OrderByDescending(r => r.DeficitQuantity).ToList();
        }

        public IReadOnlyList<TurnoverReportRow> GenerateTurnoverReport(DateTime fromDate, DateTime toDate)
        {
            var operations = _repository.GetAllOperations()
                .Where(o => o.Date.Date >= fromDate.Date && o.Date.Date <= toDate.Date)
                .ToList();

            var products = _repository.GetAllProducts();

            var result = new List<TurnoverReportRow>();

            foreach (var p in products)
            {
                var prodOps = operations.Where(o => o.ProductId == p.Id).ToList();

                var received = prodOps.Where(o => o.Type == OperationType.Receipt).ToList();
                var shipped = prodOps.Where(o => o.Type == OperationType.Expense).ToList();
                var writeOff = prodOps.Where(o => o.Type == OperationType.WriteOff).ToList();

                result.Add(new TurnoverReportRow
                {
                    Sku = p.Sku,
                    Name = p.Name,
                    ReceivedQty = received.Sum(o => o.Quantity),
                    ReceivedAmount = received.Sum(o => o.TotalAmount),
                    ShippedQty = shipped.Sum(o => o.Quantity),
                    ShippedAmount = shipped.Sum(o => o.TotalAmount),
                    WrittenOffQty = writeOff.Sum(o => o.Quantity),
                    CurrentStock = p.Quantity
                });
            }

            return result.OrderByDescending(r => r.ShippedAmount).ToList();
        }

        public void ExportStockBalanceCsv(string filePath)
        {
            var rows = GenerateStockBalanceReport();
            var sb = new StringBuilder();
            sb.AppendLine("Артикул;Наименование;Категория;Остаток;Ед.изм.;Цена закупки;Общая стоимость;Мин.остаток;Статус;Место");

            foreach (var r in rows)
            {
                sb.AppendLine($"{EscapeCsv(r.Sku)};{EscapeCsv(r.Name)};{EscapeCsv(r.Category)};{r.Quantity};{EscapeCsv(r.Unit)};{r.PurchasePrice};{r.TotalValue};{r.MinQuantity};{EscapeCsv(r.Status)};{EscapeCsv(r.Location)}");
            }

            File.WriteAllText(filePath, sb.ToString(), Encoding.UTF8);
        }

        public void ExportDeficitCsv(string filePath)
        {
            var rows = GenerateDeficitReport();
            var sb = new StringBuilder();
            sb.AppendLine("Артикул;Наименование;Категория;Текущий остаток;Мин. запас;Дефицит;Рекомендуемый заказ;Ориентировочная сумма (руб)");

            foreach (var r in rows)
            {
                sb.AppendLine($"{EscapeCsv(r.Sku)};{EscapeCsv(r.Name)};{EscapeCsv(r.Category)};{r.CurrentStock};{r.MinStock};{r.DeficitQuantity};{r.RecommendedOrderQuantity};{r.EstimatedCostRub}");
            }

            File.WriteAllText(filePath, sb.ToString(), Encoding.UTF8);
        }

        public void ExportTurnoverCsv(string filePath, DateTime fromDate, DateTime toDate)
        {
            var rows = GenerateTurnoverReport(fromDate, toDate);
            var sb = new StringBuilder();
            sb.AppendLine($"Ведомость движения товаров за период: {fromDate:dd.MM.yyyy} - {toDate:dd.MM.yyyy}");
            sb.AppendLine("Артикул;Наименование;Приход (кол-во);Приход (сумма руб);Отгрузка (кол-во);Отгрузка (сумма руб);Списано (кол-во);Текущий остаток");

            foreach (var r in rows)
            {
                sb.AppendLine($"{EscapeCsv(r.Sku)};{EscapeCsv(r.Name)};{r.ReceivedQty};{r.ReceivedAmount};{r.ShippedQty};{r.ShippedAmount};{r.WrittenOffQty};{r.CurrentStock}");
            }

            File.WriteAllText(filePath, sb.ToString(), Encoding.UTF8);
        }

        private static string EscapeCsv(string? value)
        {
            if (string.IsNullOrEmpty(value)) return string.Empty;
            if (value.Contains(';') || value.Contains('"') || value.Contains('\n'))
            {
                return $"\"{value.Replace("\"", "\"\"")}\"";
            }
            return value;
        }
    }
}
