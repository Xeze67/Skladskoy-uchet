using System;
using System.Collections.Generic;
using WarehouseAccounting.Core.Models;

namespace WarehouseAccounting.Core.Services
{
    public class DashboardStats
    {
        public int TotalItemTypes { get; set; }
        public decimal TotalStockQuantity { get; set; }
        public decimal TotalStockValueRub { get; set; }
        public int LowStockCount { get; set; }
        public int TotalOperationsCount { get; set; }
        public decimal TodayTurnoverRub { get; set; }
    }

    public interface IWarehouseService
    {
        IReadOnlyList<Product> GetProducts(string? search = null, int? categoryId = null, bool onlyLowStock = false);
        Product? GetProductById(int id);
        Product CreateProduct(Product product);
        void UpdateProduct(Product product);
        bool DeleteProduct(int id);

        WarehouseOperation ProcessReceipt(int productId, decimal quantity, decimal price, int? counterpartyId, string responsible, string comment);
        WarehouseOperation ProcessExpense(int productId, decimal quantity, decimal price, int? counterpartyId, string responsible, string comment);
        WarehouseOperation ProcessWriteOff(int productId, decimal quantity, string reason, string responsible);
        WarehouseOperation ProcessInventory(int productId, decimal actualQuantity, string responsible, string comment);

        IReadOnlyList<WarehouseOperation> GetOperationsHistory(DateTime? fromDate = null, DateTime? toDate = null, OperationType? type = null);
        IReadOnlyList<Category> GetCategories();
        Category CreateCategory(string name, string description);
        IReadOnlyList<Counterparty> GetCounterparties();
        Counterparty CreateCounterparty(string name, CounterpartyType type, string phone, string email, string address);

        DashboardStats GetDashboardStats();
        void ResetToDemo();
    }
}
