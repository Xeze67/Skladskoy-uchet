using System;

namespace WarehouseAccounting.Core.Models
{
    public class WarehouseOperation
    {
        public int Id { get; set; }
        public string DocumentNumber { get; set; } = string.Empty; // Например, ПР-0001, РХ-0002
        public DateTime Date { get; set; } = DateTime.Now;
        public OperationType Type { get; set; }
        
        public int ProductId { get; set; }
        public string ProductSku { get; set; } = string.Empty;
        public string ProductName { get; set; } = string.Empty;
        public string Unit { get; set; } = "шт.";
        
        public decimal Quantity { get; set; } // Объем операции
        public decimal Price { get; set; } // Цена за единицу в операции
        public decimal TotalAmount => Quantity * Price; // Общая сумма операции

        public int? CounterpartyId { get; set; }
        public string CounterpartyName { get; set; } = string.Empty; // Поставщик или Покупатель

        public string ResponsiblePerson { get; set; } = "Кладовщик"; // Ответственный сотрудник
        public string Comment { get; set; } = string.Empty;

        public string TypeName => Type.ToFriendlyName();
    }
}
