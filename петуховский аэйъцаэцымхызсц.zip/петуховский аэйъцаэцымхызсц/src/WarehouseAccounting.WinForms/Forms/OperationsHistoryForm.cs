using System;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using WarehouseAccounting.Core.Models;
using WarehouseAccounting.Core.Services;
using WarehouseAccounting.WinForms.UI;

namespace WarehouseAccounting.WinForms.Forms
{
    public class OperationsHistoryForm : Form
    {
        private readonly IWarehouseService _service;

        private DateTimePicker _dtpFrom = null!;
        private DateTimePicker _dtpTo = null!;
        private ComboBox _cmbTypeFilter = null!;
        private TextBox _txtSearch = null!;
        private DataGridView _gridOperations = null!;
        private Label _lblSummary = null!;

        public OperationsHistoryForm(IWarehouseService service)
        {
            _service = service;
            InitializeComponent();
            LoadOperations();
        }

        private void InitializeComponent()
        {
            this.Text = "Журнал складских документов и операций";
            this.Size = new Size(1100, 650);
            this.StartPosition = FormStartPosition.CenterParent;
            this.BackColor = ThemeColors.Background;
            this.Font = new Font("Segoe UI", 9.5f);

            // Верхняя панель заголовка
            var pnlHeader = new Panel
            {
                Dock = DockStyle.Top,
                Height = 60,
                BackColor = ThemeColors.DarkHeader,
                Padding = new Padding(20, 15, 20, 15)
            };

            var lblTitle = new Label
            {
                Text = "Журнал складских документов и движений товаров",
                Font = new Font("Segoe UI", 12f, FontStyle.Bold),
                ForeColor = Color.White,
                AutoSize = true,
                Location = new Point(20, 16)
            };
            pnlHeader.Controls.Add(lblTitle);
            this.Controls.Add(pnlHeader);

            // Панель фильтров
            var pnlFilters = new Panel
            {
                Dock = DockStyle.Top,
                Height = 55,
                BackColor = Color.White,
                Padding = new Padding(15, 10, 15, 10)
            };

            var lblPeriod = new Label { Text = "Период с:", Location = new Point(15, 16), AutoSize = true, ForeColor = ThemeColors.TextDark };
            _dtpFrom = new DateTimePicker { Location = new Point(85, 14), Size = new Size(115, 25), Format = DateTimePickerFormat.Short, Value = DateTime.Today.AddDays(-30) };
            _dtpFrom.ValueChanged += (s, e) => LoadOperations();

            var lblPeriodTo = new Label { Text = "по:", Location = new Point(210, 16), AutoSize = true, ForeColor = ThemeColors.TextDark };
            _dtpTo = new DateTimePicker { Location = new Point(235, 14), Size = new Size(115, 25), Format = DateTimePickerFormat.Short, Value = DateTime.Today.AddDays(1) };
            _dtpTo.ValueChanged += (s, e) => LoadOperations();

            var lblType = new Label { Text = "Тип:", Location = new Point(365, 16), AutoSize = true, ForeColor = ThemeColors.TextDark };
            _cmbTypeFilter = new ComboBox { Location = new Point(400, 14), Size = new Size(150, 25), DropDownStyle = ComboBoxStyle.DropDownList };
            _cmbTypeFilter.Items.AddRange(new object[] { "Все операции", "Приход", "Отгрузка (Расход)", "Списание", "Инвентаризация" });
            _cmbTypeFilter.SelectedIndex = 0;
            _cmbTypeFilter.SelectedIndexChanged += (s, e) => LoadOperations();

            var lblSearch = new Label { Text = "Поиск:", Location = new Point(565, 16), AutoSize = true, ForeColor = ThemeColors.TextDark };
            _txtSearch = new TextBox { Location = new Point(615, 14), Size = new Size(180, 25), PlaceholderText = "Артикул, товар, номер..." };
            _txtSearch.TextChanged += (s, e) => LoadOperations();

            var btnExport = new Button
            {
                Text = "📄 Экспорт CSV",
                Location = new Point(810, 12),
                Size = new Size(130, 29),
                BackColor = ThemeColors.Primary,
                ForeColor = Color.White,
                FlatStyle = FlatStyle.Flat,
                Font = new Font("Segoe UI", 9f, FontStyle.Bold),
                Cursor = Cursors.Hand
            };
            btnExport.FlatAppearance.BorderSize = 0;
            btnExport.Click += BtnExport_Click;

            var btnRefresh = new Button
            {
                Text = "🔄 Обновить",
                Location = new Point(950, 12),
                Size = new Size(110, 29),
                BackColor = Color.White,
                ForeColor = ThemeColors.TextDark,
                FlatStyle = FlatStyle.Flat,
                Cursor = Cursors.Hand
            };
            btnRefresh.Click += (s, e) => LoadOperations();

            pnlFilters.Controls.Add(lblPeriod);
            pnlFilters.Controls.Add(_dtpFrom);
            pnlFilters.Controls.Add(lblPeriodTo);
            pnlFilters.Controls.Add(_dtpTo);
            pnlFilters.Controls.Add(lblType);
            pnlFilters.Controls.Add(_cmbTypeFilter);
            pnlFilters.Controls.Add(lblSearch);
            pnlFilters.Controls.Add(_txtSearch);
            pnlFilters.Controls.Add(btnExport);
            pnlFilters.Controls.Add(btnRefresh);
            this.Controls.Add(pnlFilters);

            // Таблица операций
            _gridOperations = new DataGridView
            {
                Dock = DockStyle.Fill,
                BackgroundColor = Color.White,
                BorderStyle = BorderStyle.None,
                RowHeadersVisible = false,
                AllowUserToAddRows = false,
                AllowUserToDeleteRows = false,
                ReadOnly = true,
                SelectionMode = DataGridViewSelectionMode.FullRowSelect,
                MultiSelect = false,
                AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill,
                EnableHeadersVisualStyles = false
            };
            _gridOperations.ColumnHeadersDefaultCellStyle.BackColor = ThemeColors.GridHeaderBg;
            _gridOperations.ColumnHeadersDefaultCellStyle.Font = new Font("Segoe UI", 9.5f, FontStyle.Bold);
            _gridOperations.ColumnHeadersDefaultCellStyle.ForeColor = ThemeColors.TextDark;
            _gridOperations.ColumnHeadersHeight = 36;
            _gridOperations.RowTemplate.Height = 28;

            ConfigureGridColumns();
            this.Controls.Add(_gridOperations);

            // Нижняя панель
            var pnlFooter = new Panel
            {
                Dock = DockStyle.Bottom,
                Height = 40,
                BackColor = Color.FromArgb(241, 245, 249),
                Padding = new Padding(20, 10, 20, 10)
            };

            _lblSummary = new Label
            {
                Text = "Всего документов: 0",
                Dock = DockStyle.Left,
                AutoSize = true,
                Font = new Font("Segoe UI", 9.5f, FontStyle.Bold),
                ForeColor = ThemeColors.TextDark
            };
            pnlFooter.Controls.Add(_lblSummary);
            this.Controls.Add(pnlFooter);
        }

        private void ConfigureGridColumns()
        {
            _gridOperations.Columns.Add("DocNumber", "Документ");
            _gridOperations.Columns["DocNumber"].FillWeight = 85;

            _gridOperations.Columns.Add("Date", "Дата");
            _gridOperations.Columns["Date"].FillWeight = 80;

            _gridOperations.Columns.Add("Type", "Тип операции");
            _gridOperations.Columns["Type"].FillWeight = 90;

            _gridOperations.Columns.Add("Sku", "Артикул");
            _gridOperations.Columns["Sku"].FillWeight = 75;

            _gridOperations.Columns.Add("ProductName", "Товар");
            _gridOperations.Columns["ProductName"].FillWeight = 160;

            _gridOperations.Columns.Add("Quantity", "Кол-во");
            _gridOperations.Columns["Quantity"].FillWeight = 60;

            _gridOperations.Columns.Add("Unit", "Ед.");
            _gridOperations.Columns["Unit"].FillWeight = 40;

            _gridOperations.Columns.Add("Price", "Цена (руб)");
            _gridOperations.Columns["Price"].FillWeight = 75;

            _gridOperations.Columns.Add("Total", "Сумма (руб)");
            _gridOperations.Columns["Total"].FillWeight = 85;

            _gridOperations.Columns.Add("Counterparty", "Контрагент");
            _gridOperations.Columns["Counterparty"].FillWeight = 110;

            _gridOperations.Columns.Add("Responsible", "Ответственный");
            _gridOperations.Columns["Responsible"].FillWeight = 85;

            _gridOperations.Columns.Add("Comment", "Примечание");
            _gridOperations.Columns["Comment"].FillWeight = 110;
        }

        private void LoadOperations()
        {
            var ops = _service.GetOperationsHistory(_dtpFrom.Value, _dtpTo.Value);

            int typeIndex = _cmbTypeFilter.SelectedIndex;
            if (typeIndex == 1) ops = ops.Where(o => o.Type == OperationType.Receipt).ToList();
            else if (typeIndex == 2) ops = ops.Where(o => o.Type == OperationType.Expense).ToList();
            else if (typeIndex == 3) ops = ops.Where(o => o.Type == OperationType.WriteOff).ToList();
            else if (typeIndex == 4) ops = ops.Where(o => o.Type == OperationType.InventoryAdjustment).ToList();

            if (!string.IsNullOrWhiteSpace(_txtSearch.Text))
            {
                var q = _txtSearch.Text.Trim().ToLowerInvariant();
                ops = ops.Where(o =>
                    o.DocumentNumber.ToLowerInvariant().Contains(q) ||
                    o.ProductName.ToLowerInvariant().Contains(q) ||
                    o.ProductSku.ToLowerInvariant().Contains(q) ||
                    o.CounterpartyName.ToLowerInvariant().Contains(q) ||
                    o.ResponsiblePerson.ToLowerInvariant().Contains(q)).ToList();
            }

            _gridOperations.Rows.Clear();

            decimal totalAmount = 0m;
            foreach (var op in ops)
            {
                int rowIdx = _gridOperations.Rows.Add(
                    op.DocumentNumber,
                    op.Date.ToString("dd.MM.yyyy HH:mm"),
                    op.TypeName,
                    op.ProductSku,
                    op.ProductName,
                    op.Quantity.ToString("G29"),
                    op.Unit,
                    op.Price.ToString("N2"),
                    op.TotalAmount.ToString("N2"),
                    op.CounterpartyName,
                    op.ResponsiblePerson,
                    op.Comment
                );

                var row = _gridOperations.Rows[rowIdx];
                if (op.Type == OperationType.Receipt)
                {
                    row.Cells["Type"].Style.ForeColor = ThemeColors.Success;
                    row.Cells["Type"].Style.Font = new Font("Segoe UI", 9.5f, FontStyle.Bold);
                }
                else if (op.Type == OperationType.Expense)
                {
                    row.Cells["Type"].Style.ForeColor = ThemeColors.Primary;
                    row.Cells["Type"].Style.Font = new Font("Segoe UI", 9.5f, FontStyle.Bold);
                }
                else if (op.Type == OperationType.WriteOff)
                {
                    row.Cells["Type"].Style.ForeColor = ThemeColors.Danger;
                }

                totalAmount += op.TotalAmount;
            }

            _lblSummary.Text = $"Найдено документов: {ops.Count} | Общий оборот по выбранным операциям: {totalAmount:N2} руб.";
        }

        private void BtnExport_Click(object? sender, EventArgs e)
        {
            using var sfd = new SaveFileDialog
            {
                Filter = "CSV файлы (*.csv)|*.csv",
                FileName = $"operations_export_{DateTime.Now:yyyyMMdd_HHmm}.csv"
            };

            if (sfd.ShowDialog() == DialogResult.OK)
            {
                try
                {
                    var sb = new StringBuilder();
                    sb.AppendLine("Номер;Дата;Тип;Артикул;Товар;Количество;Ед;Цена;Сумма;Контрагент;Ответственный;Примечание");
                    foreach (DataGridViewRow row in _gridOperations.Rows)
                    {
                        var cells = row.Cells.Cast<DataGridViewCell>().Select(c => $"\"{c.Value?.ToString()?.Replace("\"", "\"\"")}\"");
                        sb.AppendLine(string.Join(";", cells));
                    }
                    File.WriteAllText(sfd.FileName, sb.ToString(), Encoding.UTF8);
                    MessageBox.Show("Данные успешно экспортированы в CSV!", "Экспорт", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Ошибка экспорта: {ex.Message}", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }
    }
}
