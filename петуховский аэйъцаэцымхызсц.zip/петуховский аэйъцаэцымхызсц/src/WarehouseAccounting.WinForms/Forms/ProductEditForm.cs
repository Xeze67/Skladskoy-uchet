using System;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;
using WarehouseAccounting.Core.Models;
using WarehouseAccounting.Core.Services;
using WarehouseAccounting.WinForms.UI;

namespace WarehouseAccounting.WinForms.Forms
{
    public class ProductEditForm : Form
    {
        private readonly IWarehouseService _service;
        private readonly Product? _existingProduct;

        private TextBox _txtSku = null!;
        private TextBox _txtName = null!;
        private ComboBox _cmbCategory = null!;
        private ComboBox _cmbUnit = null!;
        private NumericUpDown _numPurchasePrice = null!;
        private NumericUpDown _numSellingPrice = null!;
        private NumericUpDown _numQuantity = null!;
        private NumericUpDown _numMinQuantity = null!;
        private TextBox _txtLocation = null!;
        private Button _btnSave = null!;
        private Button _btnCancel = null!;

        public Product? SavedProduct { get; private set; }

        public ProductEditForm(IWarehouseService service, Product? product = null)
        {
            _service = service;
            _existingProduct = product;
            InitializeComponent();
            PopulateData();
        }

        private void InitializeComponent()
        {
            this.Text = _existingProduct == null ? "Добавление товара на склад" : "Редактирование параметров товара";
            this.Size = new Size(540, 560);
            this.StartPosition = FormStartPosition.CenterParent;
            this.FormBorderStyle = FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.BackColor = ThemeColors.Background;
            this.Font = new Font("Segoe UI", 9.5f);

            var pnlHeader = new Panel
            {
                Dock = DockStyle.Top,
                Height = 65,
                BackColor = ThemeColors.DarkHeader,
                Padding = new Padding(20, 15, 20, 15)
            };

            var lblTitle = new Label
            {
                Text = _existingProduct == null ? "Новый товар в номенклатуре" : $"Редактирование: {_existingProduct.Name}",
                Font = new Font("Segoe UI", 12f, FontStyle.Bold),
                ForeColor = Color.White,
                AutoSize = true,
                Location = new Point(20, 18)
            };
            pnlHeader.Controls.Add(lblTitle);
            this.Controls.Add(pnlHeader);

            int y = 80;
            int labelX = 30;
            int inputX = 180;
            int inputWidth = 300;
            int step = 42;

            // 1. Артикул
            AddLabel("Артикул (SKU):", labelX, y);
            _txtSku = new TextBox { Location = new Point(inputX, y - 3), Size = new Size(inputWidth, 26) };
            this.Controls.Add(_txtSku);
            y += step;

            // 2. Наименование
            AddLabel("Наименование:", labelX, y);
            _txtName = new TextBox { Location = new Point(inputX, y - 3), Size = new Size(inputWidth, 26) };
            this.Controls.Add(_txtName);
            y += step;

            // 3. Категория
            AddLabel("Категория:", labelX, y);
            _cmbCategory = new ComboBox { Location = new Point(inputX, y - 3), Size = new Size(inputWidth, 26), DropDownStyle = ComboBoxStyle.DropDown };
            this.Controls.Add(_cmbCategory);
            y += step;

            // 4. Единица измерения
            AddLabel("Ед. измерения:", labelX, y);
            _cmbUnit = new ComboBox { Location = new Point(inputX, y - 3), Size = new Size(inputWidth, 26), DropDownStyle = ComboBoxStyle.DropDown };
            _cmbUnit.Items.AddRange(new object[] { "шт.", "упак.", "кг", "м", "бухта", "баллон", "компл.", "л" });
            _cmbUnit.SelectedIndex = 0;
            this.Controls.Add(_cmbUnit);
            y += step;

            // 5. Цена закупки
            AddLabel("Цена закупки (руб):", labelX, y);
            _numPurchasePrice = new NumericUpDown { Location = new Point(inputX, y - 3), Size = new Size(inputWidth, 26), Maximum = 10000000m, DecimalPlaces = 2, ThousandsSeparator = true };
            this.Controls.Add(_numPurchasePrice);
            y += step;

            // 6. Цена реализации
            AddLabel("Цена продажи (руб):", labelX, y);
            _numSellingPrice = new NumericUpDown { Location = new Point(inputX, y - 3), Size = new Size(inputWidth, 26), Maximum = 10000000m, DecimalPlaces = 2, ThousandsSeparator = true };
            this.Controls.Add(_numSellingPrice);
            y += step;

            // 7. Начальный остаток
            AddLabel("Остаток на складе:", labelX, y);
            _numQuantity = new NumericUpDown { Location = new Point(inputX, y - 3), Size = new Size(inputWidth, 26), Maximum = 1000000m, DecimalPlaces = 2 };
            if (_existingProduct != null)
            {
                // При редактировании остаток корректируется через складские операции
                _numQuantity.Enabled = false;
            }
            this.Controls.Add(_numQuantity);
            y += step;

            // 8. Минимальный запас
            AddLabel("Мин. неснижаемый запас:", labelX, y);
            _numMinQuantity = new NumericUpDown { Location = new Point(inputX, y - 3), Size = new Size(inputWidth, 26), Maximum = 1000000m, DecimalPlaces = 2 };
            this.Controls.Add(_numMinQuantity);
            y += step;

            // 9. Место хранения
            AddLabel("Место / Ячейка:", labelX, y);
            _txtLocation = new TextBox { Location = new Point(inputX, y - 3), Size = new Size(inputWidth, 26) };
            this.Controls.Add(_txtLocation);
            y += 50;

            // Кнопки
            _btnSave = new Button
            {
                Text = "Сохранить",
                Location = new Point(inputX, y),
                Size = new Size(140, 38),
                BackColor = ThemeColors.Primary,
                ForeColor = Color.White,
                FlatStyle = FlatStyle.Flat,
                Font = new Font("Segoe UI", 9.5f, FontStyle.Bold),
                Cursor = Cursors.Hand
            };
            _btnSave.FlatAppearance.BorderSize = 0;
            _btnSave.Click += BtnSave_Click;

            _btnCancel = new Button
            {
                Text = "Отмена",
                DialogResult = DialogResult.Cancel,
                Location = new Point(inputX + 155, y),
                Size = new Size(120, 38),
                BackColor = Color.White,
                ForeColor = ThemeColors.TextDark,
                FlatStyle = FlatStyle.Flat
            };

            this.Controls.Add(_btnSave);
            this.Controls.Add(_btnCancel);
            this.AcceptButton = _btnSave;
            this.CancelButton = _btnCancel;
        }

        private void AddLabel(string text, int x, int y)
        {
            var lbl = new Label
            {
                Text = text,
                Location = new Point(x, y),
                AutoSize = true,
                ForeColor = ThemeColors.TextDark,
                Font = new Font("Segoe UI", 9.5f)
            };
            this.Controls.Add(lbl);
        }

        private void PopulateData()
        {
            var categories = _service.GetCategories();
            _cmbCategory.DataSource = categories;
            _cmbCategory.DisplayMember = "Name";
            _cmbCategory.ValueMember = "Id";

            if (_existingProduct != null)
            {
                _txtSku.Text = _existingProduct.Sku;
                _txtName.Text = _existingProduct.Name;
                _cmbUnit.Text = _existingProduct.Unit;
                _numPurchasePrice.Value = _existingProduct.PurchasePrice;
                _numSellingPrice.Value = _existingProduct.SellingPrice;
                _numQuantity.Value = _existingProduct.Quantity;
                _numMinQuantity.Value = _existingProduct.MinQuantity;
                _txtLocation.Text = _existingProduct.StorageLocation;

                var cat = categories.FirstOrDefault(c => c.Id == _existingProduct.CategoryId);
                if (cat != null)
                {
                    _cmbCategory.SelectedItem = cat;
                }
            }
            else
            {
                _txtSku.Text = string.Empty;
                _txtName.Text = string.Empty;
                _numPurchasePrice.Value = 0m;
                _numSellingPrice.Value = 0m;
                _numQuantity.Value = 1m;
                _numMinQuantity.Value = 0m;
                _txtLocation.Text = string.Empty;
                if (categories.Count > 0)
                {
                    _cmbCategory.SelectedIndex = 0;
                }
            }
        }

        private void BtnSave_Click(object? sender, EventArgs e)
        {
            string sku = _txtSku.Text.Trim();
            string name = _txtName.Text.Trim();

            if (string.IsNullOrWhiteSpace(sku))
            {
                MessageBox.Show("Введите артикул товара!", "Валидация", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                _txtSku.Focus();
                return;
            }

            if (string.IsNullOrWhiteSpace(name))
            {
                MessageBox.Show("Введите наименование товара!", "Валидация", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                _txtName.Focus();
                return;
            }

            var categories = _service.GetCategories();
            string catText = _cmbCategory.Text.Trim();
            var selectedCategory = _cmbCategory.SelectedItem as Category;
            int categoryId = 1;
            string categoryName = "Общая";

            if (selectedCategory != null)
            {
                categoryId = selectedCategory.Id;
                categoryName = selectedCategory.Name;
            }
            else if (!string.IsNullOrWhiteSpace(catText))
            {
                var existing = categories.FirstOrDefault(c => c.Name.Equals(catText, StringComparison.OrdinalIgnoreCase));
                if (existing != null)
                {
                    categoryId = existing.Id;
                    categoryName = existing.Name;
                }
                else
                {
                    try
                    {
                        var createdCat = _service.CreateCategory(catText, "Пользовательская категория");
                        categoryId = createdCat.Id;
                        categoryName = createdCat.Name;
                    }
                    catch
                    {
                        categoryName = catText;
                    }
                }
            }

            string unit = string.IsNullOrWhiteSpace(_cmbUnit.Text) ? "шт." : _cmbUnit.Text.Trim();

            try
            {
                if (_existingProduct == null)
                {
                    var product = new Product
                    {
                        Sku = sku,
                        Name = name,
                        CategoryId = categoryId,
                        CategoryName = categoryName,
                        Unit = unit,
                        PurchasePrice = _numPurchasePrice.Value,
                        SellingPrice = _numSellingPrice.Value,
                        Quantity = _numQuantity.Value,
                        MinQuantity = _numMinQuantity.Value,
                        StorageLocation = _txtLocation.Text.Trim()
                    };

                    SavedProduct = _service.CreateProduct(product);
                }
                else
                {
                    _existingProduct.Sku = sku;
                    _existingProduct.Name = name;
                    _existingProduct.CategoryId = categoryId;
                    _existingProduct.CategoryName = categoryName;
                    _existingProduct.Unit = unit;
                    _existingProduct.PurchasePrice = _numPurchasePrice.Value;
                    _existingProduct.SellingPrice = _numSellingPrice.Value;
                    _existingProduct.MinQuantity = _numMinQuantity.Value;
                    _existingProduct.StorageLocation = _txtLocation.Text.Trim();

                    _service.UpdateProduct(_existingProduct);
                    SavedProduct = _existingProduct;
                }

                this.DialogResult = DialogResult.OK;
                this.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка сохранения: {ex.Message}", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
