using System;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;
using WarehouseAccounting.Core.Exceptions;
using WarehouseAccounting.Core.Models;
using WarehouseAccounting.Core.Services;
using WarehouseAccounting.WinForms.UI;

namespace WarehouseAccounting.WinForms.Forms
{
    public class OperationForm : Form
    {
        private readonly IWarehouseService _service;
        private readonly OperationType _initialType;
        private readonly int? _preselectedProductId;

        private ComboBox _cmbOpType = null!;
        private ComboBox _cmbProduct = null!;
        private ComboBox _cmbCounterparty = null!;
        private Label _lblStockInfo = null!;
        private NumericUpDown _numQuantity = null!;
        private NumericUpDown _numPrice = null!;
        private Label _lblTotalAmount = null!;
        private ComboBox _cmbResponsible = null!;
        private TextBox _txtComment = null!;
        private Button _btnExecute = null!;
        private Button _btnCancel = null!;

        public WarehouseOperation? ExecutedOperation { get; private set; }

        public OperationForm(IWarehouseService service, OperationType type = OperationType.Receipt, int? productId = null)
        {
            _service = service;
            _initialType = type;
            _preselectedProductId = productId;
            InitializeComponent();
            PopulateData();
        }

        private void InitializeComponent()
        {
            this.Text = "Оформление складской операции";
            this.Size = new Size(580, 560);
            this.StartPosition = FormStartPosition.CenterParent;
            this.FormBorderStyle = FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.BackColor = ThemeColors.Background;
            this.Font = new Font("Segoe UI", 9.5f);

            var pnlHeader = new Panel
            {
                Dock = DockStyle.Top,
                Height = 65,
                BackColor = ThemeColors.DarkHeader,
                Padding = new Padding(20, 15, 20, 15)
            };

            var lblTitle = new Label
            {
                Text = "Проведение складской операции",
                Font = new Font("Segoe UI", 12f, FontStyle.Bold),
                ForeColor = Color.White,
                AutoSize = true,
                Location = new Point(20, 18)
            };
            pnlHeader.Controls.Add(lblTitle);
            this.Controls.Add(pnlHeader);

            int y = 80;
            int labelX = 25;
            int inputX = 185;
            int inputWidth = 350;
            int step = 42;

            // 1. Тип операции
            AddLabel("Тип операции:", labelX, y);
            _cmbOpType = new ComboBox { Location = new Point(inputX, y - 3), Size = new Size(inputWidth, 26), DropDownStyle = ComboBoxStyle.DropDownList };
            _cmbOpType.Items.Add(new { Text = "Приход от поставщика (+)", Value = OperationType.Receipt });
            _cmbOpType.Items.Add(new { Text = "Отгрузка клиенту / Расход (-)", Value = OperationType.Expense });
            _cmbOpType.Items.Add(new { Text = "Списание брака/порчи (-)", Value = OperationType.WriteOff });
            _cmbOpType.Items.Add(new { Text = "Инвентаризация (корректировка)", Value = OperationType.InventoryAdjustment });
            _cmbOpType.DisplayMember = "Text";
            _cmbOpType.ValueMember = "Value";
            _cmbOpType.SelectedIndexChanged += CmbOpType_SelectedIndexChanged;
            this.Controls.Add(_cmbOpType);
            y += step;

            // 2. Выбор товара
            AddLabel("Товар со склада:", labelX, y);
            _cmbProduct = new ComboBox { Location = new Point(inputX, y - 3), Size = new Size(inputWidth, 26), DropDownStyle = ComboBoxStyle.DropDownList };
            _cmbProduct.SelectedIndexChanged += CmbProduct_SelectedIndexChanged;
            this.Controls.Add(_cmbProduct);
            y += 28;

            // Инфо о текущем остатке
            _lblStockInfo = new Label
            {
                Text = "Текущий остаток: 0 шт.",
                Location = new Point(inputX, y),
                AutoSize = true,
                ForeColor = ThemeColors.TextMuted,
                Font = new Font("Segoe UI", 8.5f, FontStyle.Italic)
            };
            this.Controls.Add(_lblStockInfo);
            y += 24;

            // 3. Контрагент
            AddLabel("Контрагент:", labelX, y);
            _cmbCounterparty = new ComboBox { Location = new Point(inputX, y - 3), Size = new Size(inputWidth, 26), DropDownStyle = ComboBoxStyle.DropDownList };
            this.Controls.Add(_cmbCounterparty);
            y += step;

            // 4. Количество
            AddLabel("Количество:", labelX, y);
            _numQuantity = new NumericUpDown { Location = new Point(inputX, y - 3), Size = new Size(inputWidth, 26), Maximum = 1000000m, DecimalPlaces = 2, Value = 1m };
            _numQuantity.ValueChanged += RecalculateTotal;
            this.Controls.Add(_numQuantity);
            y += step;

            // 5. Цена за единицу
            AddLabel("Цена за ед. (руб):", labelX, y);
            _numPrice = new NumericUpDown { Location = new Point(inputX, y - 3), Size = new Size(inputWidth, 26), Maximum = 10000000m, DecimalPlaces = 2, ThousandsSeparator = true };
            _numPrice.ValueChanged += RecalculateTotal;
            this.Controls.Add(_numPrice);
            y += 30;

            // Сумма операции
            _lblTotalAmount = new Label
            {
                Text = "Итоговая сумма: 0.00 руб.",
                Location = new Point(inputX, y),
                AutoSize = true,
                ForeColor = ThemeColors.Primary,
                Font = new Font("Segoe UI", 10f, FontStyle.Bold)
            };
            this.Controls.Add(_lblTotalAmount);
            y += 30;

            // 6. Ответственный
            AddLabel("Ответственный:", labelX, y);
            _cmbResponsible = new ComboBox { Location = new Point(inputX, y - 3), Size = new Size(inputWidth, 26), DropDownStyle = ComboBoxStyle.DropDown };
            _cmbResponsible.Items.AddRange(new object[] { "Ложкин", "Барышев", "Рейтер" });
            _cmbResponsible.SelectedIndex = 0;
            this.Controls.Add(_cmbResponsible);
            y += step;

            // 7. Примечание
            AddLabel("Основание / Примечание:", labelX, y);
            _txtComment = new TextBox { Location = new Point(inputX, y - 3), Size = new Size(inputWidth, 26) };
            this.Controls.Add(_txtComment);
            y += 50;

            // Кнопки
            _btnExecute = new Button
            {
                Text = "✔ Провести документ",
                Location = new Point(inputX, y),
                Size = new Size(180, 38),
                BackColor = ThemeColors.Success,
                ForeColor = Color.White,
                FlatStyle = FlatStyle.Flat,
                Font = new Font("Segoe UI", 9.5f, FontStyle.Bold),
                Cursor = Cursors.Hand
            };
            _btnExecute.FlatAppearance.BorderSize = 0;
            _btnExecute.Click += BtnExecute_Click;

            _btnCancel = new Button
            {
                Text = "Отмена",
                DialogResult = DialogResult.Cancel,
                Location = new Point(inputX + 195, y),
                Size = new Size(115, 38),
                BackColor = Color.White,
                ForeColor = ThemeColors.TextDark,
                FlatStyle = FlatStyle.Flat
            };

            this.Controls.Add(_btnExecute);
            this.Controls.Add(_btnCancel);
            this.AcceptButton = _btnExecute;
            this.CancelButton = _btnCancel;
        }

        private void AddLabel(string text, int x, int y)
        {
            var lbl = new Label
            {
                Text = text,
                Location = new Point(x, y),
                AutoSize = true,
                ForeColor = ThemeColors.TextDark,
                Font = new Font("Segoe UI", 9.5f)
            };
            this.Controls.Add(lbl);
        }

        private void PopulateData()
        {
            var products = _service.GetProducts();
            _cmbProduct.DataSource = products;
            _cmbProduct.DisplayMember = "Name";
            _cmbProduct.ValueMember = "Id";

            if (_preselectedProductId.HasValue)
            {
                var target = products.FirstOrDefault(p => p.Id == _preselectedProductId.Value);
                if (target != null) _cmbProduct.SelectedItem = target;
            }

            int targetIndex = _initialType switch
            {
                OperationType.Receipt => 0,
                OperationType.Expense => 1,
                OperationType.WriteOff => 2,
                OperationType.InventoryAdjustment => 3,
                _ => 0
            };
            _cmbOpType.SelectedIndex = targetIndex;

            UpdateCounterparties();
            UpdateProductPrices();
        }

        private void CmbOpType_SelectedIndexChanged(object? sender, EventArgs e)
        {
            UpdateCounterparties();
            UpdateProductPrices();
        }

        private void UpdateCounterparties()
        {
            var currentType = GetSelectedType();
            var counterparties = _service.GetCounterparties();

            _cmbCounterparty.Items.Clear();
            _cmbCounterparty.Items.Add(new Counterparty { Id = 0, Name = "(Без контрагента)" });

            if (currentType == OperationType.Receipt)
            {
                foreach (var c in counterparties.Where(c => c.Type == CounterpartyType.Supplier))
                    _cmbCounterparty.Items.Add(c);
            }
            else if (currentType == OperationType.Expense)
            {
                foreach (var c in counterparties.Where(c => c.Type == CounterpartyType.Customer))
                    _cmbCounterparty.Items.Add(c);
            }

            if (_cmbCounterparty.Items.Count > 1)
                _cmbCounterparty.SelectedIndex = 1;
            else
                _cmbCounterparty.SelectedIndex = 0;

            _cmbCounterparty.Enabled = currentType == OperationType.Receipt || currentType == OperationType.Expense;
        }

        private void CmbProduct_SelectedIndexChanged(object? sender, EventArgs e)
        {
            UpdateProductPrices();
        }

        private void UpdateProductPrices()
        {
            if (_cmbProduct.SelectedItem is Product prod)
            {
                var type = GetSelectedType();
                _lblStockInfo.Text = $"Текущий остаток на складе: {prod.Quantity} {prod.Unit} | Мин. запас: {prod.MinQuantity} {prod.Unit} [{prod.StorageLocation}]";
                if (prod.IsLowStock)
                {
                    _lblStockInfo.ForeColor = ThemeColors.Danger;
                    _lblStockInfo.Text += " ⚠ ДЕФИЦИТ";
                }
                else
                {
                    _lblStockInfo.ForeColor = ThemeColors.TextMuted;
                }

                if (type == OperationType.Receipt)
                {
                    _numPrice.Value = prod.PurchasePrice;
                }
                else if (type == OperationType.Expense)
                {
                    _numPrice.Value = prod.SellingPrice;
                }
                else
                {
                    _numPrice.Value = prod.PurchasePrice;
                }

                if (type == OperationType.InventoryAdjustment)
                {
                    _numQuantity.Value = prod.Quantity;
                }
            }
            RecalculateTotal(this, EventArgs.Empty);
        }

        private void RecalculateTotal(object? sender, EventArgs e)
        {
            decimal total = _numQuantity.Value * _numPrice.Value;
            _lblTotalAmount.Text = $"Итоговая сумма: {total:N2} руб.";
        }

        private OperationType GetSelectedType()
        {
            if (_cmbOpType.SelectedIndex == 1) return OperationType.Expense;
            if (_cmbOpType.SelectedIndex == 2) return OperationType.WriteOff;
            if (_cmbOpType.SelectedIndex == 3) return OperationType.InventoryAdjustment;
            return OperationType.Receipt;
        }

        private void BtnExecute_Click(object? sender, EventArgs e)
        {
            if (_cmbProduct.SelectedItem is not Product product)
            {
                MessageBox.Show("Выберите товар!", "Внимание", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            var type = GetSelectedType();
            decimal qty = _numQuantity.Value;
            decimal price = _numPrice.Value;

            if (qty <= 0 && type != OperationType.InventoryAdjustment)
            {
                MessageBox.Show("Количество должно быть строго больше нуля!", "Внимание", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            int? counterpartyId = null;
            if (_cmbCounterparty.SelectedItem is Counterparty cp && cp.Id > 0)
            {
                counterpartyId = cp.Id;
            }

            string responsible = _cmbResponsible.Text.Trim();
            string comment = _txtComment.Text.Trim();

            try
            {
                switch (type)
                {
                    case OperationType.Receipt:
                        ExecutedOperation = _service.ProcessReceipt(product.Id, qty, price, counterpartyId, responsible, comment);
                        break;
                    case OperationType.Expense:
                        ExecutedOperation = _service.ProcessExpense(product.Id, qty, price, counterpartyId, responsible, comment);
                        break;
                    case OperationType.WriteOff:
                        ExecutedOperation = _service.ProcessWriteOff(product.Id, qty, comment, responsible);
                        break;
                    case OperationType.InventoryAdjustment:
                        ExecutedOperation = _service.ProcessInventory(product.Id, qty, responsible, comment);
                        break;
                }

                MessageBox.Show($"Операция успешно проведена!\nНомер документа: {ExecutedOperation?.DocumentNumber}", "Успех", MessageBoxButtons.OK, MessageBoxIcon.Information);
                this.DialogResult = DialogResult.OK;
                this.Close();
            }
            catch (InsufficientStockException ex)
            {
                MessageBox.Show(ex.Message, "Ошибка: Недостаток остатка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка выполнения операции: {ex.Message}", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
