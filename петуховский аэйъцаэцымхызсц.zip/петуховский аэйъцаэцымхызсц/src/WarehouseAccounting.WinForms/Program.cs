using System;
using System.Windows.Forms;
using WarehouseAccounting.WinForms.Forms;

namespace WarehouseAccounting.WinForms
{
    internal static class Program
    {
        [STAThread]
        static void Main()
        {
            ApplicationConfiguration.Initialize();
            Application.Run(new MainForm());
        }
    }
}
