using System;
using System.IO;
using System.Linq;
using WarehouseAccounting.Core.Data;
using WarehouseAccounting.Core.Services;
using Xunit;

namespace WarehouseAccounting.Tests
{
    public class ReportServiceTests : IDisposable
    {
        private readonly string _testDbPath;
        private readonly IWarehouseRepository _repository;
        private readonly IReportService _reportService;

        public ReportServiceTests()
        {
            _testDbPath = Path.Combine(Path.GetTempPath(), $"test_warehouse_report_{Guid.NewGuid()}.json");
            _repository = new JsonWarehouseRepository(_testDbPath);
            _reportService = new ReportService(_repository);
        }

        public void Dispose()
        {
            if (File.Exists(_testDbPath))
            {
                try { File.Delete(_testDbPath); } catch { }
            }
        }

        [Fact]
        public void GenerateStockBalanceReport_ReturnsAllRowsWithCorrectStatus()
        {
            var rows = _reportService.GenerateStockBalanceReport();

            Assert.NotEmpty(rows);
            Assert.Contains(rows, r => r.Status == "ДЕФИЦИТ");
            Assert.Contains(rows, r => r.Status == "В норме");
            Assert.All(rows, r => Assert.True(r.TotalValue == r.Quantity * r.PurchasePrice));
        }

        [Fact]
        public void GenerateDeficitReport_ReturnsOnlyItemsWithDeficit()
        {
            var deficitRows = _reportService.GenerateDeficitReport();

            Assert.NotEmpty(deficitRows);
            Assert.All(deficitRows, r =>
            {
                Assert.True(r.CurrentStock <= r.MinStock);
                Assert.True(r.DeficitQuantity > 0);
                Assert.True(r.RecommendedOrderQuantity > 0);
            });
        }

        [Fact]
        public void GenerateTurnoverReport_AggregatesOperationsWithinPeriod()
        {
            var fromDate = DateTime.Now.AddDays(-30);
            var toDate = DateTime.Now.AddDays(1);

            var turnover = _reportService.GenerateTurnoverReport(fromDate, toDate);

            Assert.NotEmpty(turnover);
            Assert.Contains(turnover, t => t.ReceivedQty > 0 || t.ShippedQty > 0 || t.WrittenOffQty > 0);
        }

        [Fact]
        public void ExportStockBalanceCsv_CreatesNonEmptyCsvFile()
        {
            string csvFile = Path.Combine(Path.GetTempPath(), $"export_test_{Guid.NewGuid()}.csv");

            try
            {
                _reportService.ExportStockBalanceCsv(csvFile);

                Assert.True(File.Exists(csvFile));
                var lines = File.ReadAllLines(csvFile);
                Assert.True(lines.Length > 1);
                Assert.Contains("Артикул;Наименование", lines[0]);
            }
            finally
            {
                if (File.Exists(csvFile))
                {
                    try { File.Delete(csvFile); } catch { }
                }
            }
        }

        [Fact]
        public void ExportDeficitCsv_CreatesValidFile()
        {
            string csvFile = Path.Combine(Path.GetTempPath(), $"export_deficit_{Guid.NewGuid()}.csv");

            try
            {
                _reportService.ExportDeficitCsv(csvFile);

                Assert.True(File.Exists(csvFile));
                var lines = File.ReadAllLines(csvFile);
                Assert.True(lines.Length > 1);
                Assert.Contains("Дефицит", lines[0]);
            }
            finally
            {
                if (File.Exists(csvFile))
                {
                    try { File.Delete(csvFile); } catch { }
                }
            }
        }
    }
}
