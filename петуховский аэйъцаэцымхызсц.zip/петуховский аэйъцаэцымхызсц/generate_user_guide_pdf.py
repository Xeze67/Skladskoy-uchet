import os
from reportlab.lib.pagesizes import A4
from reportlab.lib import colors
from reportlab.lib.units import mm
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.platypus import (
    SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, PageBreak, HRFlowable, Image
)
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont

pdfmetrics.registerFont(TTFont('Arial', r'C:\Windows\Fonts\arial.ttf'))
pdfmetrics.registerFont(TTFont('Arial-Bold', r'C:\Windows\Fonts\arialbd.ttf'))
pdfmetrics.registerFont(TTFont('Arial-Italic', r'C:\Windows\Fonts\ariali.ttf'))

pdf_path = 'docs/Руководство_пользователя_Складской_учёт.pdf'
os.makedirs('docs', exist_ok=True)

doc = SimpleDocTemplate(
    pdf_path,
    pagesize=A4,
    leftMargin=20*mm,
    rightMargin=20*mm,
    topMargin=20*mm,
    bottomMargin=20*mm
)

styles = getSampleStyleSheet()

title_style = ParagraphStyle(
    'UGTitle',
    fontName='Arial-Bold',
    fontSize=20,
    leading=25,
    alignment=1,
    textColor=colors.HexColor('#0F172A')
)

subtitle_style = ParagraphStyle(
    'UGSubtitle',
    fontName='Arial',
    fontSize=12,
    leading=16,
    alignment=1,
    textColor=colors.HexColor('#475569')
)

h1_style = ParagraphStyle(
    'UGH1',
    fontName='Arial-Bold',
    fontSize=13,
    leading=17,
    textColor=colors.HexColor('#1E293B'),
    spaceBefore=12,
    spaceAfter=6,
    keepWithNext=True
)

h2_style = ParagraphStyle(
    'UGH2',
    fontName='Arial-Bold',
    fontSize=10.5,
    leading=14,
    textColor=colors.HexColor('#2563EB'),
    spaceBefore=8,
    spaceAfter=4,
    keepWithNext=True
)

body_style = ParagraphStyle(
    'UGBody',
    fontName='Arial',
    fontSize=9,
    leading=13,
    textColor=colors.HexColor('#1E293B'),
    spaceBefore=2,
    spaceAfter=3
)

bullet_style = ParagraphStyle(
    'UGBullet',
    fontName='Arial',
    fontSize=9,
    leading=13,
    textColor=colors.HexColor('#1E293B'),
    leftIndent=12,
    spaceBefore=1,
    spaceAfter=2
)

note_style = ParagraphStyle(
    'UGNote',
    fontName='Arial-Italic',
    fontSize=8.5,
    leading=12,
    textColor=colors.HexColor('#0369A1'),
    spaceBefore=3,
    spaceAfter=4
)

story = []

# ==================== ТИТУЛЬНЫЙ ЛИСТ ====================
story.append(Spacer(1, 30*mm))
story.append(Paragraph("СИСТЕМА АВТОМАТИЗАЦИИ СКЛАДСКОГО УЧЕТА", subtitle_style))
story.append(Spacer(1, 10*mm))

story.append(HRFlowable(width="100%", thickness=2.5, color=colors.HexColor('#2563EB'), spaceAfter=15))
story.append(Paragraph("РУКОВОДСТВО ПОЛЬЗОВАТЕЛЯ", title_style))
story.append(Spacer(1, 4*mm))
story.append(Paragraph("Программный комплекс «Складской учёт (мини-версия)»", subtitle_style))
story.append(Spacer(1, 2*mm))
story.append(Paragraph("Тема проекта № 9", ParagraphStyle('T9', fontName='Arial-Bold', fontSize=11, alignment=1, textColor=colors.HexColor('#2563EB'))))
story.append(HRFlowable(width="100%", thickness=2.5, color=colors.HexColor('#2563EB'), spaceBefore=15, spaceAfter=45*mm))

meta_text = """
<b>Разработчики программного обеспечения:</b><br/>
• <b>Ложкин</b> — Тимлид, Архитектор ядра<br/>
• <b>Барышев</b> — Разработчик графического интерфейса<br/>
• <b>Рейтер</b> — Разработчик базы данных и аналитики<br/><br/>
<b>Версия программы:</b> 1.0.0 Release (Final)<br/>
<b>Платформа:</b> Microsoft .NET 9.0 Windows Forms
"""
story.append(Paragraph(meta_text, body_style))
story.append(Spacer(1, 30*mm))
story.append(Paragraph("2026 г.", ParagraphStyle('Year', fontName='Arial', fontSize=10, alignment=1, textColor=colors.HexColor('#64748B'))))

story.append(PageBreak())

# ==================== ОГЛАВЛЕНИЕ ====================
story.append(Paragraph("Содержание", h1_style))
story.append(HRFlowable(width="100%", thickness=0.8, color=colors.HexColor('#CBD5E1'), spaceAfter=8))

toc_items = [
    "1. Введение и общее описание системы",
    "2. Системные требования и порядок запуска",
    "3. Структура интерфейса главного окна (Дашборд склада)",
    "4. Управление номенклатурой товаров (Карточка товара, категории)",
    "5. Оформление складских операций:",
    "   5.1. Приход товара от поставщика (+)",
    "   5.2. Отгрузка покупателю (-) и защита от отрицательного остатка",
    "   5.3. Списание брака и поврежденной продукции",
    "   5.4. Проведение инвентаризации и корректировка остатков",
    "6. Журнал складских документов и фильтрация проводок",
    "7. Аналитические отчеты и экспорт данных в CSV / Excel",
    "8. Функция сброса базы к демонстрационным данным",
    "9. Часто задаваемые вопросы (FAQ) и устранение неполадок"
]
for item in toc_items:
    story.append(Paragraph(item, bullet_style))

story.append(Spacer(1, 6*mm))

# ==================== 1. ВВЕДЕНИЕ ====================
story.append(Paragraph("1. Введение и общее описание системы", h1_style))
story.append(HRFlowable(width="100%", thickness=0.8, color=colors.HexColor('#CBD5E1'), spaceAfter=6))
story.append(Paragraph(
    "Программный комплекс <b>«Складской учёт (мини-версия)»</b> предназначен для оперативного ведения складского "
    "учета на предприятиях оптово-розничной торговли, сервисных центрах, мастерских и складских участках. "
    "Программа автоматизирует учет приходов, отгрузок, списаний и инвентаризаций, обеспечивает непрерывный мониторинг "
    "критических неснижаемых запасов и формирует управленческую отчетность.",
    body_style
))

# ==================== 2. СИСТЕМНЫЕ ТРЕБОВАНИЯ ====================
story.append(Paragraph("2. Системные требования и порядок запуска", h1_style))
story.append(HRFlowable(width="100%", thickness=0.8, color=colors.HexColor('#CBD5E1'), spaceAfter=6))
story.append(Paragraph("<b>Минимальные системные требования:</b>", h2_style))
story.append(Paragraph("• Операционная система: Microsoft Windows 10 или Windows 11 (x64).", bullet_style))
story.append(Paragraph("• Среда выполнения: .NET 9.0 Runtime (или .NET 9.0 SDK для сборки из исходных кодов).", bullet_style))
story.append(Paragraph("• Оперативная память: не менее 512 МБ доступной памяти.", bullet_style))
story.append(Paragraph("• Свободное дисковое пространство: от 50 МБ.", bullet_style))
story.append(Paragraph("• Разрешение экрана: от 1024×768 точек (рекомендуется 1920×1080).", bullet_style))

story.append(Paragraph("<b>Порядок первого запуска:</b>", h2_style))
story.append(Paragraph("1. Запустите исполняемый файл <code>WarehouseAccounting.WinForms.exe</code> (или дважды кликните по файлу <code>Запустить_Складской_Учёт.bat</code> в корне проекта).", bullet_style))
story.append(Paragraph("2. При первом старте программа автоматически подключается к локальной базе данных Microsoft Access <code>warehouse.accdb</code>, содержащей каталог товаров (электроинструмент, крепеж, сантехника, стройхимия) и журнал операций.", bullet_style))
story.append(Paragraph("3. На экране отобразится главное окно с актуальными показателями склада.", bullet_style))

story.append(PageBreak())

# ==================== 3. ИНТЕРФЕЙС ГЛАВНОГО ОКНА ====================
story.append(Paragraph("3. Структура интерфейса главного окна", h1_style))
story.append(HRFlowable(width="100%", thickness=0.8, color=colors.HexColor('#CBD5E1'), spaceAfter=6))
story.append(Paragraph(
    "Главное окно программы спроектировано по принципу интерактивного дашборда и разделено на функциональные зоны:",
    body_style
))

story.append(Paragraph("<b>1. Верхняя панель управления (Header):</b> содержит заголовок программы и кнопки быстрого доступа к вспомогательным модулям: «Журнал операций», «Отчёты», «Категории», «Сброс к демо» и «О программе».", bullet_style))
story.append(Paragraph("<b>2. Информационные карточки KPI:</b>", bullet_style))
story.append(Paragraph("   • <i>Всего номенклатуры:</i> общее количество зарегистрированных видов товаров.", bullet_style))
story.append(Paragraph("   • <i>Общий остаток:</i> суммарное количество единиц всех товаров на складе.", bullet_style))
story.append(Paragraph("   • <i>Оценка склада:</i> общая балансовая стоимость запасов в рублях (остаток × цена закупки).", bullet_style))
story.append(Paragraph("   • <i>Дефицит (к дозаказу):</i> число позиций, фактический остаток которых упал ниже неснижаемого уровня (выделяется ярким цветом).", bullet_style))
story.append(Paragraph("<b>3. Панель действий со складом:</b> кнопки создания прихода (зеленая), отгрузки (синяя), списания брака (оранжевая), инвентаризации (фиолетовая), а также добавления, изменения и удаления позиций.", bullet_style))
story.append(Paragraph("<b>4. Панель фильтрации и поиска:</b> поиск по части наименования, артикула или ячейки, выпадающий список категорий и флаг «Только позиции в дефиците».", bullet_style))
story.append(Paragraph("<b>5. Таблица номенклатуры (DataGridView):</b> центральная рабочая область. Строки с дефицитным остатком автоматически окрашиваются в нежно-красный цвет с пометкой «⚠ ДЕФИЦИТ». Двойной щелчок по строке открывает форму редактирования товара.", bullet_style))

# ==================== 4. УПРАВЛЕНИЕ НОМЕНКЛАТУРОЙ ====================
story.append(Paragraph("4. Управление номенклатурой товаров", h1_style))
story.append(HRFlowable(width="100%", thickness=0.8, color=colors.HexColor('#CBD5E1'), spaceAfter=6))

story.append(Paragraph("<b>Добавление нового товара:</b>", h2_style))
story.append(Paragraph("1. Нажмите кнопку <b>«+ Новый товар»</b> на панели действий.", bullet_style))
story.append(Paragraph("2. В открывшемся окне введите точные параметры: Артикул (SKU), Наименование, Категорию (выберите существующую или введите новую), Единицу измерения (шт, упак, кг, м, бухта и др.), Цену закупки, Цену реализации, Начальный остаток, Минимальный запас и Ячейку склада (например, 'Стеллаж A-1'). Поля вводятся вручную именно так, как вам требуется (без автоматических случайных кодов).", bullet_style))
story.append(Paragraph("3. Нажмите кнопку <b>«Сохранить»</b>. Товар сохранится в базу данных Microsoft Access и сразу появится в таблице, а сводные показатели склада пересчитаются.", bullet_style))

story.append(Paragraph("<b>Редактирование параметров товара:</b>", h2_style))
story.append(Paragraph("Выберите товар в таблице и нажмите кнопку <b>«✏ Редактировать»</b> (или дважды щелкните левой кнопкой мыши). Измените необходимые поля и сохраните изменения. Обратите внимание: физический остаток на складе изменяется через складские операции (приход, расход, инвентаризация) для сохранения истории документооборота.", bullet_style))

story.append(Paragraph("<b>Удаление товара:</b>", h2_style))
story.append(Paragraph("Для удаления неактуального товара выделите строку и нажмите кнопку <b>«🗑 Удалить»</b>, после чего подтвердите действие в появившемся диалоговом окне.", bullet_style))

story.append(PageBreak())

# ==================== 5. СКЛАДСКИЕ ОПЕРАЦИИ ====================
story.append(Paragraph("5. Оформление складских операций", h1_style))
story.append(HRFlowable(width="100%", thickness=0.8, color=colors.HexColor('#CBD5E1'), spaceAfter=6))

story.append(Paragraph("<b>5.1. Приход товара от поставщика (+)</b>", h2_style))
story.append(Paragraph("1. Выберите в таблице товар (или откройте окно операции без предварительного выбора) и нажмите кнопку <b>«+ Приход товара»</b>.", bullet_style))
story.append(Paragraph("2. В форме операции будет автоматически выбран тип «Приход от поставщика (+)».", bullet_style))
story.append(Paragraph("3. Выберите контрагента-поставщика из выпадающего списка (или оставьте без привязки).", bullet_style))
story.append(Paragraph("4. Укажите количество поступившего товара и закупочную цену за единицу. Итоговая сумма накладной рассчитается автоматически.", bullet_style))
story.append(Paragraph("5. При необходимости укажите ответственного кладовщика и примечание (номер накладной, договор).", bullet_style))
story.append(Paragraph("6. Нажмите <b>«✔ Провести документ»</b>. Приход будет зафиксирован с присвоением номера (например, ПР-0005), а остаток на складе увеличится.", bullet_style))

story.append(Paragraph("<b>5.2. Отгрузка покупателю (-) и защита от отрицательного остатка</b>", h2_style))
story.append(Paragraph("1. Выделите позицию и нажмите кнопку <b>«- Отгрузка (Расход)»</b>.", bullet_style))
story.append(Paragraph("2. В форме отобразится текущий доступный остаток на складе.", bullet_style))
story.append(Paragraph("3. Введите отгружаемое количество. <b>Внимание:</b> если введенное количество превышает фактический остаток, программа заблокирует проводку с ошибкой <i>«Недостаточно товара на складе! Запрошено: X, доступно: Y»</i>.", bullet_style))
story.append(Paragraph("4. После подтверждения формируется расходный документ (РХ-0004), остаток товара списывается, а выручка фиксируется в аналитике.", bullet_style))

story.append(Paragraph("<b>5.3. Списание брака и поврежденной продукции</b>", h2_style))
story.append(Paragraph("Для списания товара в результате механических повреждений, истечения срока годности или производственного дефекта нажмите <b>«⚠ Списание брака»</b>. Укажите причину списания в поле примечания (например, 'Бой упаковки при разгрузке'). Товар списывается по себестоимости закупки без начисления выручки (документ СП-0002).", bullet_style))

story.append(Paragraph("<b>5.4. Проведение инвентаризации</b>", h2_style))
story.append(Paragraph("Для выравнивания фактического наличия с учетным нажмите кнопку <b>«📋 Инвентаризация»</b>. Введите фактическое количество, пересчитанное на стеллаже. Программа автоматически вычислит разницу (излишек со знаком '+' или недостачу со знаком '-') и скорректирует учетный остаток, сохранив акт инвентаризации (ИНВ-0002).", bullet_style))

# ==================== 6. ЖУРНАЛ ОПЕРАЦИЙ ====================
story.append(Paragraph("6. Журнал складских документов", h1_style))
story.append(HRFlowable(width="100%", thickness=0.8, color=colors.HexColor('#CBD5E1'), spaceAfter=6))
story.append(Paragraph(
    "Для просмотра полной истории складских движений нажмите кнопку <b>«📋 Журнал операций»</b> на верхней панели. "
    "Окно журнала позволяет фильтровать документы по диапазону дат («Период с / по»), по типу операции "
    "(Приход, Отгрузка, Списание, Инвентаризация) и выполнять поиск по номеру документа или контрагенту. "
    "Журнал содержит кнопку <b>«📄 Экспорт CSV»</b> для выгрузки отфильтрованных проводок.",
    body_style
))

# ==================== 7. АНАЛИТИЧЕСКИЕ ОТЧЕТЫ ====================
story.append(Paragraph("7. Аналитические отчеты и экспорт в CSV / Excel", h1_style))
story.append(HRFlowable(width="100%", thickness=0.8, color=colors.HexColor('#CBD5E1'), spaceAfter=6))
story.append(Paragraph(
    "Модуль аналитики открывается по кнопке <b>«📊 Отчёты»</b> и содержит три специализированные ведомости:",
    body_style
))
story.append(Paragraph("1. <b>📦 Ведомость остатков:</b> инвентарный список всей номенклатуры с количеством, ценами, общей суммой оценки и статусом дефицита. Кнопка «Экспорт CSV» сохраняет отчет в файл для открытия в Excel.", bullet_style))
story.append(Paragraph("2. <b>⚠ Ведомость дефицита (к заказу):</b> специализированная ведомость для менеджера по закупкам. Включает только позиции, остаток которых ниже нормы, автоматически вычисляет рекомендуемый объем заказа для восполнения запаса и ориентировочный требуемый бюджет в рублях.", bullet_style))
story.append(Paragraph("3. <b>📊 Движение товаров (обороты):</b> оборотно-сальдовая ведомость за выбранный период. Показывает начальный остаток, поступившее количество и сумму, отгруженный объем и текущее сальдо.", bullet_style))

story.append(PageBreak())

# ==================== 8. СБРОС К ДЕМО ====================
story.append(Paragraph("8. Сброс базы к демонстрационным данным", h1_style))
story.append(HRFlowable(width="100%", thickness=0.8, color=colors.HexColor('#CBD5E1'), spaceAfter=6))
story.append(Paragraph(
    "Для проведения демонстраций или защиты проекта в программе предусмотрена кнопка <b>«⚡ Сброс к демо»</b> "
    "на верхней панели. При подтверждении база данных Microsoft Access (<code>warehouse.accdb</code>) мгновенно сбрасывается к эталонному набору из 11 товаров, "
    "5 категорий, 4 контрагентов и 6 первичных документов прихода и отгрузки. Это гарантирует воспроизводимость "
    "любых тестовых сценариев.",
    body_style
))

# ==================== 9. FAQ ====================
story.append(Paragraph("9. Часто задаваемые вопросы (FAQ) и решение проблем", h1_style))
story.append(HRFlowable(width="100%", thickness=0.8, color=colors.HexColor('#CBD5E1'), spaceAfter=6))

faq_items = [
    (
        "В: Почему при попытке отгрузки появляется сообщение 'Недостаточно товара на складе'?",
        "О: В системе реализована защита целостности данных. Вы не можете списать со склада больше товара, чем фактически числится на остатке. Проведите документ прихода или инвентаризацию перед отгрузкой."
    ),
    (
        "В: Где физически хранятся данные склада?",
        "О: Все данные сохраняются в реляционной базе данных Microsoft Access (<code>warehouse.accdb</code>) в каталоге программы. Файл можно открыть напрямую в MS Access для проверки таблиц, скопировать или перенести на другой ПК."
    ),
    (
        "В: Как открыть экспортированный CSV-файл в Microsoft Excel?",
        "О: CSV-файлы формируются в кодировке UTF-8 с разделителем точка с запятой (';'). Для открытия в Excel дважды щелкните по файлу или воспользуйтесь функцией 'Данные -> Из текстового/CSV-файла'."
    ),
    (
        "В: Как быстро найти товар на определенном стеллаже?",
        "О: Введите название стеллажа (например, 'A-1' или 'Стеллаж B') в строку поиска в верхней части главного окна. Таблица мгновенно отфильтрует товары, расположенные в указанной ячейке."
    )
]

for q, a in faq_items:
    story.append(Paragraph(f"<b>{q}</b>", h2_style))
    story.append(Paragraph(a, body_style))

def add_header_footer(canvas, doc_obj):
    if doc_obj.page > 1:
        canvas.saveState()
        canvas.setFont('Arial', 8)
        canvas.setFillColor(colors.HexColor('#64748B'))
        
        # Header
        canvas.drawString(20*mm, 297*mm - 12*mm, "Программный комплекс «Складской учёт (мини-версия)» | Руководство пользователя")
        canvas.setStrokeColor(colors.HexColor('#E2E8F0'))
        canvas.setLineWidth(0.5)
        canvas.line(20*mm, 297*mm - 14*mm, 190*mm, 297*mm - 14*mm)
        
        # Footer
        canvas.line(20*mm, 15*mm, 190*mm, 15*mm)
        canvas.drawString(20*mm, 10*mm, "Тема № 9 • Разработчики: Ложкин, Барышев, Рейтер")
        canvas.drawRightString(190*mm, 10*mm, f"Стр. {doc_obj.page}")
        canvas.restoreState()

doc.build(story, onLaterPages=add_header_footer)
print(f"User Guide PDF created successfully at {pdf_path}")
