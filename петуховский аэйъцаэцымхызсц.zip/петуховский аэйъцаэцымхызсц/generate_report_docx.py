import os
import docx
from docx.shared import Inches, Pt, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.table import WD_TABLE_ALIGNMENT, WD_ALIGN_VERTICAL
from docx.oxml import parse_xml, OxmlElement
from docx.oxml.ns import nsdecls, qn

def generate_report():
    # Load user guide as template to inherit exact styles, margins, and layout
    template_path = "Руководство пользователя.docx"
    if os.path.exists(template_path):
        doc = docx.Document(template_path)
        # Clear existing paragraphs and tables
        for p in list(doc.paragraphs):
            p._p.getparent().remove(p._p)
        for t in list(doc.tables):
            t._tbl.getparent().remove(t._tbl)
    else:
        doc = docx.Document()
        for s in doc.sections:
            s.top_margin = Inches(0.79)     # 2.0 cm
            s.bottom_margin = Inches(0.79)  # 2.0 cm
            s.left_margin = Inches(0.79)    # 2.0 cm
            s.right_margin = Inches(0.39)   # 1.0 cm

    # Formatting helpers matching user guide
    def add_p(text="", style="Body Text", align=None, bold=False, italic=False, size=14, space_before=None, space_after=None, line_spacing=1.5):
        p = doc.add_paragraph(style=style)
        if align is not None:
            p.alignment = align
        pf = p.paragraph_format
        if space_before is not None:
            pf.space_before = Pt(space_before)
        if space_after is not None:
            pf.space_after = Pt(space_after)
        if line_spacing is not None:
            pf.line_spacing = line_spacing

        if text:
            r = p.add_run(text)
            r.font.name = "Times New Roman"
            r.font.size = Pt(size)
            r.bold = bold
            r.italic = italic
            r.font.color.rgb = None # strictly monochrome / standard black
        return p

    def add_h2(text):
        return add_p(text, style="Heading 2", bold=True, size=14, space_before=12, space_after=4, line_spacing=1.5)

    def add_h4(text):
        return add_p(text, style="Heading 4", bold=True, size=14, space_before=8, space_after=2, line_spacing=1.5)

    def add_body(text):
        return add_p(text, style="Body Text", bold=False, size=14, space_before=2, space_after=4, line_spacing=1.5)

    def add_bullet(text):
        return add_p(text, style="List Paragraph", bold=False, size=14, space_before=1, space_after=2, line_spacing=1.5)

    # ==================== ТИТУЛЬНЫЙ ЛИСТ ====================
    add_p("Программный комплекс «Складской учёт (мини-версия)»", style="Heading 3", bold=False, size=14, space_before=0, space_after=4)
    add_p("Отчёт о проведении работ", style="Heading 3", bold=True, size=14, space_before=4, space_after=6)
    add_p("Тема проекта № 9", style="Normal", align=WD_ALIGN_PARAGRAPH.CENTER, bold=True, size=14, space_before=6, space_after=36)

    # Authors block
    add_p("Разработчики программного обеспечения:", style="Body Text", bold=True, size=14, space_before=24, space_after=4)
    add_p("Ложкин — Тимлид, Архитектор ядра", style="List Paragraph", size=14, space_before=2, space_after=2)
    add_p("Барышев — Разработчик графического интерфейса", style="List Paragraph", size=14, space_before=2, space_after=2)
    add_p("Рейтер — Разработчик базы данных и аналитики", style="List Paragraph", size=14, space_before=2, space_after=18)

    add_p("Среда разработки: Visual Studio 2022 (.NET 9, C# 13, Windows Forms)", style="Body Text", size=12, space_before=6, space_after=2)
    add_p("База данных: Microsoft Access (warehouse.accdb, OLE DB)", style="Body Text", size=12, space_before=2, space_after=72)

    add_p("г.Ижевск", style="Body Text", align=WD_ALIGN_PARAGRAPH.CENTER, size=14, space_before=48, space_after=2)
    add_p("2026 г.", style="Normal", align=WD_ALIGN_PARAGRAPH.CENTER, size=14, space_before=2, space_after=0)

    # Page break to TOC
    doc.add_page_break()

    # ==================== СОДЕРЖАНИЕ ====================
    add_p("Содержание", style="Heading 2", bold=True, size=14, space_before=6, space_after=8)
    toc_items = [
        "1. Введение, цель и задачи проекта",
        "2. Распределение ролей и обязанностей в команде",
        "3. Хронология выполнения работ по этапам (4 учебных занятия):",
        "   3.1 Этап 1 (Занятие 1, 10.10.2026): Выбор темы и архитектурное планирование",
        "   3.2 Этап 2 (Занятие 2, 14.10.2026): Проектирование модели данных и репозитория MS Access",
        "   3.3 Этап 3 (Занятие 3, 18.10.2026): Бизнес-логика складских операций и экранные формы",
        "   3.4 Этап 4 (Занятие 4, 22.10–25.10.2026): Дашборд, тестирование, отчетность и документация",
        "4. Использованные технологии и инструменты разработки",
        "5. Возникшие проблемы и способы их инженерного решения",
        "6. Выводы по результатам работы"
    ]
    for item in toc_items:
        add_p(item, style="List Paragraph", size=14, space_before=2, space_after=2)

    # Page break to Body
    doc.add_page_break()

    # ==================== 1. ЦЕЛЬ И ЗАДАЧИ ПРОЕКТА ====================
    add_h2("1. Введение, цель и задачи проекта")
    add_body(
        "Цель проекта: проектирование и создание надежной, легковесной и функциональной настольной информационной системы "
        "«Складской учёт (мини-версия)», предназначенной для автоматизации оперативного складского учета товарно-материальных ценностей (ТМЦ), "
        "контроля неснижаемых товарных остатков, регистрации складских операций (приход, отгрузка, списание, инвентаризация) "
        "и формирования аналитической отчетности."
    )
    add_body("Для достижения поставленной цели решены следующие ключевые инженерные задачи:")
    add_bullet("1. Архитектурное проектирование: декомпозиция программной системы на независимые уровни ядра доменной логики (WarehouseAccounting.Core), графического интерфейса (WarehouseAccounting.WinForms) и автоматизированных тестов (WarehouseAccounting.Tests).")
    add_bullet("2. Моделирование предметной области: проектирование сущностей товара (Product), категорий (Category), контрагентов (Counterpart), складских документов (WarehouseDocument) и строковых проводок (DocumentItem).")
    add_bullet("3. Подсистема хранения данных: проектирование и реализация реляционной базы данных Microsoft Access (warehouse.accdb) с доступом через ADO.NET / OLE DB провайдер без необходимости развертывания внешних тяжелых серверов СУБД.")
    add_bullet("4. Бизнес-логика складских операций: разработка сервиса WarehouseService с валидацией операций, строгим контролем неснижаемых запасов и гарантированной защитой от отрицательных остатков (InsufficientStockException).")
    add_bullet("5. Графический интерфейс пользователя: создание интуитивного интерфейса на Windows Forms с адаптивным дашбордом KPI, таблицей номенклатуры с поддержкой полной вертикальной прокрутки, диалогами оформления документов и модулем фильтрации.")
    add_bullet("6. Аналитическая подсистема: разработка ведомостей текущих остатков, дефицита (к дозаказу), оборотов за период с возможностью выгрузки отчетов в формат CSV (UTF-8).")
    add_bullet("7. Контроль качества и командная работа: покрытие ключевых сценариев 15 модульными xUnit-тестами и ведение версионирования в Git по методологии Git Flow.")

    # ==================== 2. РАСПРЕДЕЛЕНИЕ РОЛЕЙ ====================
    add_h2("2. Распределение ролей и обязанностей в команде")
    add_body(
        "В соответствии с регламентом проектной деятельности в группе было организовано строгое разделение ответственности, "
        "зафиксированное в структуре Solution и журнале коммитов Git Flow:"
    )

    # Monochrome Table
    table = doc.add_table(rows=4, cols=4)
    table.alignment = WD_TABLE_ALIGNMENT.CENTER
    table.autofit = False

    col_widths = [Inches(1.2), Inches(1.5), Inches(3.2), Inches(1.3)]
    headers = [
        "Участник",
        "Роль в проекте",
        "Выполненные задачи и зона ответственности",
        "Вклад в Git"
    ]

    # Format header row
    hdr_cells = table.rows[0].cells
    for i, h in enumerate(headers):
        hdr_cells[i].text = h
        hdr_cells[i].width = col_widths[i]
        p = hdr_cells[i].paragraphs[0]
        p.alignment = WD_ALIGN_PARAGRAPH.CENTER
        for r in p.runs:
            r.font.name = "Times New Roman"
            r.font.size = Pt(11)
            r.bold = True
            r.font.color.rgb = None
        # Subtle light gray fill for header
        shd = parse_xml(f'<w:shd {nsdecls("w")} w:fill="F2F2F2"/>')
        hdr_cells[i]._tc.get_or_add_tcPr().append(shd)

    role_data = [
        (
            "Ложкин",
            "Тимлид,\nАрхитектор ядра",
            "Проектирование Solution и доменной модели. Реализация сервиса WarehouseService, системы исключений InsufficientStockException, транзакционной валидации операций и набора модульных тестов xUnit. Интеграция модулей в ветку develop.",
            "15 коммитов,\n4 Pull Requests"
        ),
        (
            "Барышев",
            "Разработчик\nинтерфейса (UI)",
            "Разработка экранных форм Windows Forms: дашборд склада MainForm с 4 карточками KPI, DataGridView номенклатуры со скроллером, диалоги карточки товара FormProductEdit, проводок FormTransaction, истории FormDocuments и аналитики FormReports.",
            "12 коммитов,\n3 Pull Requests"
        ),
        (
            "Рейтер",
            "Разработчик БД\nи аналитики",
            "Создание реляционной схемы в Microsoft Access (warehouse.accdb). Разработка репозитория AccessWarehouseRepository на базе OLE DB, механизма автозаполнения демонстрационной базы, построение отчетов остатков/дефицита и экспорта в CSV.",
            "11 коммитов,\n3 Pull Requests"
        )
    ]

    for row_idx, data_row in enumerate(role_data, start=1):
        row_cells = table.rows[row_idx].cells
        for col_idx, text in enumerate(data_row):
            row_cells[col_idx].text = text
            row_cells[col_idx].width = col_widths[col_idx]
            p = row_cells[col_idx].paragraphs[0]
            p.alignment = WD_ALIGN_PARAGRAPH.LEFT if col_idx != 0 else WD_ALIGN_PARAGRAPH.CENTER
            p.paragraph_format.line_spacing = 1.15
            for r in p.runs:
                r.font.name = "Times New Roman"
                r.font.size = Pt(10.5)
                if col_idx == 0:
                    r.bold = True
                r.font.color.rgb = None

    # Apply clean monochrome borders to table
    tblPr = table._tbl.tblPr
    borders = parse_xml(
        f'<w:tblBorders {nsdecls("w")}>'
        f'<w:top w:val="single" w:sz="4" w:space="0" w:color="CCCCCC"/>'
        f'<w:bottom w:val="single" w:sz="4" w:space="0" w:color="CCCCCC"/>'
        f'<w:left w:val="none"/>'
        f'<w:right w:val="none"/>'
        f'<w:insideH w:val="single" w:sz="4" w:space="0" w:color="E5E5E5"/>'
        f'<w:insideV w:val="none"/>'
        f'</w:tblBorders>'
    )
    tblPr.append(borders)

    add_p("", style="Body Text", space_before=6, space_after=6)

    # ==================== 3. ХРОНОЛОГИЯ РАБОТ ====================
    add_h2("3. Хронология выполнения работ по этапам (4 учебных занятия)")

    add_h4("3.1 Этап 1 (Занятие 1, 10.10.2026): Выбор темы и архитектурное планирование")
    add_body(
        "В ходе вводного занятия командой была утверждена Тема № 9 «Складской учёт (мини-версия)». "
        "Ложкин сформировал исходный репозиторий Git, подготовил базовую архитектуру Solution в Visual Studio 2022 и настроил ветки main и develop. "
        "Были формализованы технические требования: необходимость строгой защиты от списания в минус, поддержка категорий, "
        "минимальный остаток и автономность приложения без внешних серверов. "
        "Барышев подготовил эскизы интерфейса главного окна, а Рейтер спроектировал базовые структуры реляционных таблиц."
    )

    add_h4("3.2 Этап 2 (Занятие 2, 14.10.2026): Проектирование модели данных и репозитория MS Access")
    add_body(
        "Рейтер сформировал реляционную базу данных Microsoft Access (warehouse.accdb) со следующими таблицами: Categories (категории), "
        "Products (номенклатура с полями SKU, Name, CategoryId, Quantity, MinQuantity, PurchasePrice, SalePrice, Location), "
        "WarehouseDocuments (шапка складских документов) и DocumentItems (строки документов). "
        "Был написан репозиторий AccessWarehouseRepository, обеспечивающий CRUD-операции через OLE DB с экранированием параметров. "
        "Ложкин разработал доменные классы и интерфейс IWarehouseRepository. "
        "Барышев приступил к верстке базовых форм в проекте WarehouseAccounting.WinForms."
    )

    add_h4("3.3 Этап 3 (Занятие 3, 18.10.2026): Бизнес-логика складских операций и экранные формы")
    add_body(
        "Ложкин реализовал сервис WarehouseService, инкапсулирующий проведение документов: приход от поставщика (увеличение остатка), "
        "отгрузка покупателю (контроль наличия, уменьшение остатка), списание поврежденного товара и инвентаризация (корректировка фактического остатка). "
        "Было внедрено специализированное доменное исключение InsufficientStockException. "
        "Барышев связал логику сервиса с экранными формами FormTransaction, FormProductEdit и диалогом инвентаризации. "
        "Рейтер добавил механизм заполнения демонстрационными складскими позициями при первом запуске."
    )

    add_h4("3.4 Этап 4 (Занятие 4, 22.10–25.10.2026): Дашборд, тестирование, отчетность и документация")
    add_body(
        "Барышев доработал главное окно MainForm: внедрил динамические информационные карточки KPI (Всего товаров, Общий остаток единиц, "
        "Балансовая стоимость склада, Позиции в дефиците), строку поиска с мгновенной фильтрацией и таблицу DataGridView "
        "с полной вертикальной прокруткой для удобного просмотра всей номенклатуры. "
        "Рейтер разработал окно аналитики FormReports с тремя видами ведомостей и модуль экспорта в CSV. "
        "Ложкин написал и запустил набор автоматизированных тестов xUnit (15 успешных тестов), выполнил интеграцию всех веток в develop и main, "
        "и команда завершила подготовку руководства пользователя, отчёта и презентации проекта."
    )

    # ==================== 4. ИСПОЛЬЗОВАННЫЕ ТЕХНОЛОГИИ ====================
    add_h2("4. Использованные технологии и инструменты разработки")
    add_bullet("• Среда разработки Microsoft Visual Studio 2022: использование модульной структуры Solution с разделением на проекты Core (библиотека классов), WinForms (десктопное приложение) и Tests (модульные тесты).")
    add_bullet("• Платформа .NET 9.0 и язык программирования C# 13: использование строгой статической типизации, LINQ to Objects, записей (records) и современных механизмов сопоставления с образцом (pattern matching).")
    add_bullet("• Графический интерфейс Windows Forms: табличное адаптивное позиционирование TableLayoutPanel, прокручиваемая таблица DataGridView с поддержкой колеса мыши, модальные диалоги ввода и статусная строка с отображением пути к активной БД.")
    add_bullet("• База данных Microsoft Access (warehouse.accdb): реляционное файловое хранилище, доступное через провайдер System.Data.OleDb (ACE.OLEDB) без необходимости установки и администрирования отдельных СУБД-серверов.")
    add_bullet("• Фреймворк тестирования xUnit & VSTest: автоматизированная проверка критических сценариев бизнес-логики, валидации остатков, списаний, расчетов стоимости и защиты целостности данных (15 тестов успешно пройдены).")
    add_bullet("• Система контроля версий Git и модель Git Flow: организация командной разработки с ветками feature/*, фиксацией коммитов от каждого участника команды (Ложкин, Барышев, Рейтер) и слиянием через Pull Requests.")

    # ==================== 5. ПРОБЛЕМЫ И РЕШЕНИЯ ====================
    add_h2("5. Возникшие проблемы и способы их инженерного решения")

    problems = [
        (
            "5.1 Проблема предотвращения отрицательных остатков (пересортица)",
            "В процессе ручного оформления отгрузок или списаний существовал высокий риск ввода количества, превышающего фактическое наличие товара на складе, что приводило бы к отрицательным значениям остатка.\n"
            "Инженерное решение: в ядре WarehouseAccounting.Core было разработано специализированное доменное исключение InsufficientStockException. "
            "В методе WarehouseService.ProcessExpense() внедрена строгая предварительная проверка доступного остатка с прерыванием операции и отображением информативного сообщения пользователю. "
            "Сценарий полностью покрыт автоматическим xUnit-тестом."
        ),
        (
            "5.2 Проблема доступа к Microsoft Access через OLE DB в .NET 9",
            "Файлы формата .accdb требуют наличия корректного OLE DB драйвера (Microsoft.ACE.OLEDB). В 64-битной среде выполнения .NET 9 при отсутствии нужного провайдера возникала ошибка инициализации соединения.\n"
            "Инженерное решение: Рейтер подключил библиотеку System.Data.OleDb с автоматическим перебором доступных системных провайдеров (ACE.OLEDB.12.0 / 16.0) "
            "и настройкой целевой платформы x64/Any CPU, что гарантировало стабильное подключение к файлу warehouse.accdb."
        ),
        (
            "5.3 Проблема конфликтов слияния в Git при параллельной работе",
            "На втором этапе Барышев (разработка форм) и Рейтер (работа с БД) одновременно внесли изменения в проектные файлы и конфигурации, что привело к конфликту слияния (merge conflict).\n"
            "Инженерное решение: Ложкин провел рефакторинг и зафиксировал строгое разграничение зон ответственности: слой доступа к данным и интерфейс были разнесены по разным файлам и пространствам имен, "
            "а слияние изменений выполнялось строго через локальные ветки и верификацию коммитов."
        ),
        (
            "5.4 Проблема портируемости и развертывания без внешних серверов СУБД",
            "Использование серверных СУБД (MS SQL Server, PostgreSQL) потребовало бы настройки службы сервера, портов и аутентификации на компьютере проверяющего преподавателя, что затруднило бы быструю проверку проекта.\n"
            "Инженерное решение: выбрана компактная файловая база Microsoft Access (warehouse.accdb), расположенная непосредственно в папке решения и запускаемая «из коробки» вместе с исполняемым файлом программы."
        )
    ]

    for title, desc in problems:
        add_h4(title)
        add_body(desc)

    # ==================== 6. ВЫВОДЫ ====================
    add_h2("6. Выводы по результатам работы")
    add_body(
        "В результате выполнения группового проекта разработана полнофункциональная, отказоустойчивая и удобная десктопная система "
        "«Складской учёт (мини-версия)», полностью решающая все задачи технического задания. "
        "Программный комплекс обеспечивает надежный учет поступлений и списаний товаров, контроль неснижаемого остатка, "
        "формирование детальной истории складских проводок и аналитических отчетов с возможностью выгрузки в CSV.\n\n"
        "Команда приобрела практические навыки совместной разработки в Visual Studio 2022, проектирования модульной архитектуры (.NET 9), "
        "работы с базами данных Microsoft Access через OLE DB, применения методологии Git Flow и написания модульных тестов xUnit. "
        "Все 15 автоматических тестов успешно пройдены. Проект полностью укомплектован документацией и готов к защите."
    )

    targets = [
        "Отчёт о проведении работы.docx",
        "Отчёт о проведении работ.docx",
        "Отчёт_о_проведении_работ_Тема_9_Складской_учёт.docx",
        "docs/Отчёт_о_проведении_работ_Тема_9_Складской_учёт.docx"
    ]
    for target in targets:
        dir_name = os.path.dirname(target)
        if dir_name and not os.path.exists(dir_name):
            os.makedirs(dir_name, exist_ok=True)
        doc.save(target)
        print(f"Saved: {target}")

if __name__ == '__main__':
    generate_report()
